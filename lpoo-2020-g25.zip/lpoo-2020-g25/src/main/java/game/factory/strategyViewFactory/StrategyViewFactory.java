package game.factory.strategyViewFactory;

import game.model.State.ArenaElements.Enemie.RandomMovementStrategy;
import game.model.State.ArenaElements.Enemie.Strategy;
import game.view.ChaseSnakeView;
import game.view.RandomMovementView;
import game.view.StrategyView;

public class StrategyViewFactory {
    public StrategyViewFactory() {}

    public StrategyView createStrategyView(Strategy strategy){
        if(strategy instanceof RandomMovementStrategy)
            return new RandomMovementView();
        else
            return new ChaseSnakeView();
    }
}
