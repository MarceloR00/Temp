package game.factory.stateFactory;

import game.controller.GameController;
import game.controller.StateController;
import game.model.State.State;

public class BackArenaFactory implements StateFactory{
    public State createState(GameController gameController) {
        return gameController.getGame().getArena();
    }

    public StateController createStateController(GameController gameController, State state) {
        return gameController.getArenaController();
    }
}
