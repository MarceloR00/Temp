package game.factory.stateFactory;

import game.commands.LoseMenuCommands;
import game.controller.GameController;
import game.controller.LoseMenuController;
import game.controller.StateController;
import game.model.State.LoseMenu;
import game.model.Position;
import game.model.State.State;
import game.view.LoseMenuView;

public class LoseMenuFactory implements StateFactory{
    public LoseMenu createState(GameController gameController){
        return new LoseMenu(new Position(gameController.getGame().getWidth()/2-4,
                gameController.getGame().getHeight()/4-1));
    }

    public StateController createStateController(GameController gameController, State state) {
        return new LoseMenuController((LoseMenu) state, new LoseMenuView((LoseMenu) state), new LoseMenuCommands());
    }
}
