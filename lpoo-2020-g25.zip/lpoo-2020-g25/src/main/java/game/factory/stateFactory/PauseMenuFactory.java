package game.factory.stateFactory;

import game.commands.PauseMenuCommands;
import game.controller.GameController;
import game.controller.PauseMenuController;
import game.controller.StateController;
import game.model.State.PauseMenu;
import game.model.Position;
import game.model.State.State;
import game.view.PauseMenuView;
;

public class PauseMenuFactory implements StateFactory{
    public PauseMenu createState(GameController gameController){
        return new PauseMenu(new Position(gameController.getGame().getWidth()/2-4,gameController.getGame().getHeight()/4-1));
    }

    public StateController createStateController(GameController gameController, State state) {
        return new PauseMenuController((PauseMenu) state, new PauseMenuView((PauseMenu) state), new PauseMenuCommands());
    }
}
