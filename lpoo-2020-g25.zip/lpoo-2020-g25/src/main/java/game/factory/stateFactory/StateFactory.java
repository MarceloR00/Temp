package game.factory.stateFactory;

import game.controller.GameController;
import game.controller.StateController;
import game.model.State.State;

public interface StateFactory {
    State createState(GameController gameController);
    StateController createStateController(GameController gameController, State state);
}
