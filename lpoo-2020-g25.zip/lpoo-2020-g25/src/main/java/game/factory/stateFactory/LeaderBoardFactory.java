package game.factory.stateFactory;

import game.commands.LeaderBoardCommands;
import game.controller.GameController;
import game.controller.LeaderBoardController;
import game.controller.StateController;
import game.model.Position;
import game.model.State.LeaderBoard;
import game.model.State.State;
import game.view.LeaderBoardView;

public class LeaderBoardFactory implements StateFactory{
    @Override
    public State createState(GameController gameController) {
        return new LeaderBoard(
                new Position(gameController.getGame().getWidth()/2-4,gameController.getGame().getHeight()/4-1));
    }

    @Override
    public StateController createStateController(GameController gameController, State state) {
        return new LeaderBoardController(
                new LeaderBoardView(gameController.getGame().getLeaderBoard()),new LeaderBoardCommands(),
                gameController.getGame().getLeaderBoard());
    }
}
