package game.factory.stateFactory;

import game.ArenaCreator;
import game.commands.ArenaCommands;
import game.controller.*;
import game.model.State.Arena;
import game.model.State.State;
import game.view.ArenaView;
import game.view.EnemieView;
import game.view.SnakeView;

import java.util.Random;

public class ArenaFactory implements StateFactory{
    public State createState(GameController gameController) {
        return new ArenaCreator(new Random()).produceNewArena(gameController.getGame().getWidth(),
                gameController.getGame().getHeight(), gameController.getGame().getLevel());
    }

    public StateController createStateController(GameController gameController, State state) {
        return new ArenaController((Arena) state, createArenaView(state), new ArenaCommands());
    }

    private ArenaView createArenaView(State state){
        return new ArenaView((Arena) state, new SnakeView(((Arena) state).getSnake()),
                new EnemieView(((Arena) state).getEnemies()));
    }
}
