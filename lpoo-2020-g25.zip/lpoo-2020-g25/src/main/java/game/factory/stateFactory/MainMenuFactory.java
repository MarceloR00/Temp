package game.factory.stateFactory;

import game.commands.MainMenuCommands;
import game.controller.GameController;
import game.controller.MainMenuController;
import game.controller.StateController;
import game.model.State.MainMenu;
import game.model.Position;
import game.model.State.State;
import game.view.MainMenuView;

public class MainMenuFactory implements StateFactory {
    public MainMenu createState(GameController gameController){
        return new MainMenu(new Position(gameController.getGame().getWidth()/2-4,
                gameController.getGame().getHeight()/4-1));
    }

    public StateController createStateController(GameController gameController, State state) {
        return new MainMenuController((MainMenu) state, new MainMenuView((MainMenu) state), new MainMenuCommands());
    }
}
