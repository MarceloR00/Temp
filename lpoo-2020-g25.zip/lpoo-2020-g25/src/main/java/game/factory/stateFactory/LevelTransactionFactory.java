package game.factory.stateFactory;

import game.commands.LevelTransactionCommands;
import game.controller.GameController;
import game.controller.LevelTransactionController;
import game.controller.StateController;
import game.model.State.LevelTransaction;
import game.model.Position;
import game.model.State.State;
import game.view.LevelTransactionView;

public class LevelTransactionFactory implements StateFactory{
    public LevelTransaction createState(GameController gameController){
        return new LevelTransaction(new Position(gameController.getGame().getWidth()/2-4,
                gameController.getGame().getHeight()/4-1),gameController.getGame().getLevel());
    }

    public StateController createStateController(GameController gameController, State state) {
        return new LevelTransactionController((LevelTransaction) state, new LevelTransactionView((LevelTransaction) state),new LevelTransactionCommands());
    }
}
