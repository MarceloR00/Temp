package game.controller;

import com.googlecode.lanterna.screen.Screen;
import game.commands.LoseMenuCommands;
import game.model.State.LoseMenu;
import game.view.LoseMenuView;

import java.io.IOException;

public class LoseMenuController  implements StateController{
    LoseMenu loseMenu;
    LoseMenuView loseMenuView;
    LoseMenuCommands loseMenuCommands;

    public LoseMenuController(LoseMenu loseMenu, LoseMenuView loseMenuView, LoseMenuCommands loseMenuCommands){
        this.loseMenu = loseMenu;
        this.loseMenuView = loseMenuView;
        this.loseMenuCommands = loseMenuCommands;
    }

    public LoseMenu getLoseMenu(){return this.loseMenu;}

    public void draw(Screen screen) {
        loseMenuView.draw(screen);
    }

    public void getNextCommand(Screen screen, GameController gameController) throws IOException { loseMenuView.getNextCommand(screen, loseMenuCommands, gameController);}
}
