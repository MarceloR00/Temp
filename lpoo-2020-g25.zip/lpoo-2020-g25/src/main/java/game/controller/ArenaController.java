package game.controller;

import com.googlecode.lanterna.screen.Screen;
import game.commands.ArenaCommands;
import game.factory.stateFactory.LeaderBoardFactory;
import game.factory.stateFactory.LevelTransactionFactory;
import game.factory.stateFactory.LoseMenuFactory;
import game.model.*;
import game.model.Direction.*;
import game.model.State.Arena;
import game.model.State.ArenaElements.Enemie.Enemie;
import game.view.ArenaView;

import java.io.IOException;
import java.util.List;

public class ArenaController implements StateController {
    Arena arena;
    ArenaView arenaView;
    ArenaCommands arenaCommands;

    private long frames;

    public ArenaController(Arena arena, ArenaView arenaView, ArenaCommands arenaCommands) {
        this.arena  = arena;
        this.arenaView = arenaView;
        this.arenaCommands = arenaCommands;
        this.frames = 0;
    }

    public void setFrames(long frames) {
        this.frames = frames;
    }

    public void setArena(Arena arena){ this.arena = arena; }

    public Arena getArena(){return this.arena;}

    public long getFrames(){return this.frames;}

    public void incFrames(){this.frames++;}

    public void getNextCommand(Screen screen, GameController gameController) throws IOException { arenaView.getNextCommand(screen, arenaCommands, gameController); }

    public void draw(Screen screen) { arenaView.draw(screen); }

    public void defineSnakeDirection(Direction direction){
        arena.getSnake().setInitialDirection(direction);
        arena.setMovingObjects(true);
    }

    public void updateArena(GameController gameController, Position position, Direction direction){
        if (decideIfMoves(gameController, position)){
            if(!direction.isNull())
                addChangeDirectionToSnake(direction);
            incPositionBodyOnSnake();
        }
        moveEnemies(gameController);
    }

    private boolean decideIfMoves(GameController gameController, Position position){

        if(arena.getSnake().BodyPartInThatPosition(position)){
            gameController.getGame().setLevel(1);
            if(gameController.newRecordBeaten())
                gameController.changeStates(new LeaderBoardFactory());
            else
                gameController.changeStates(new LoseMenuFactory());
            gameController.getGame().resetScore();
            return false;
        }
        else if(arena.AppleInThatPosition(position)){
            eatApple(gameController, position);
            addNewBodyPartToSnake(arena.getSnake().copyLastPosition(),arena.getSnake().copyLastDirection());
            return true;
        }
        else
            return arena.canMoveTo(position);

    }

    private void eatApple(GameController gameController, Position position){
        List<Position> apples = arena.getApples();
        for(int i = 0; i< apples.size(); i++){
            if(apples.get(i).equals(position)){
                gameController.getGame().updateScore();
                apples.remove(i);
                break;
            }
        }
        verifyLevelPassed(gameController);
    }

    private void moveEnemies(GameController gameController){
        List<Enemie> enemies = arena.getEnemies();
        for(Enemie enemie:enemies){
            Position nextPosition = enemie.getNextPosition();
            if(!arena.arenaContainObjectInPosition(nextPosition))
                enemie.setPosition(nextPosition);
        }
        verifyLevelLost(gameController);
    }

    private void verifyLevelPassed(GameController gameController){
        if(arena.verifyLevelPassed()) {
            gameController.getGame().nextLevel();
            gameController.changeStates(new LevelTransactionFactory());
        }
    }

    private void verifyLevelLost(GameController gameController){
        if(arena.verifyLevelLost()){
            gameController.getGame().setLevel(1);
            if(gameController.newRecordBeaten())
                gameController.changeStates(new LeaderBoardFactory());
            else
                gameController.changeStates(new LoseMenuFactory());
            gameController.getGame().resetScore();
        }
    }

    public void addChangeDirectionToSnake(Direction direction) {
        Position position = new Position(arena.getSnake().getHeadOfSnake().getPosition().getX(), arena.getSnake().getHeadOfSnake().getPosition().getY());

        List<BodyPart> body = arena.getSnake().getBody();
        for (int i = 0; i < body.size(); i++) {
            if (i == 0)
                body.get(i).setDirection(direction);
            else
                body.get(i).addChangeDirections(position, direction);
        }
    }

    public void incPositionBodyOnSnake() {
        List<BodyPart> body = arena.getSnake().getBody();
        for (BodyPart bodyPart : body)
            bodyPart.goNextPosition();

    }

    public void addNewBodyPartToSnake(Position position,Direction direction){
        BodyPart newBodyPart = createBodyPartAccordingToDirectionAndPosition(position,direction);
        getUpdatedAboutChangeDirections(newBodyPart);
        arena.getSnake().addNewBodyPart(newBodyPart);
    }

    private BodyPart createBodyPartAccordingToDirectionAndPosition(Position position, Direction direction){
        return new BodyPart(direction.getOpositePosition(position), direction);
    }

    private void getUpdatedAboutChangeDirections(BodyPart bodyPart){
        List<ChangeDirection> tmp = arena.getSnake().getTailOfSnake().getChangeDirections();
        for(ChangeDirection changeDirection:tmp){
            bodyPart.addChangeDirections(new Position(changeDirection.getPosition().getX(),changeDirection.getPosition().getY()),
                    changeDirection.getDirection().copy());
        }
    }
}
