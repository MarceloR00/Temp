package game.controller;

import com.googlecode.lanterna.screen.Screen;
import game.commands.MainMenuCommands;
import game.model.State.MainMenu;
import game.view.MainMenuView;

import java.io.IOException;


public class MainMenuController implements StateController {
    MainMenu mainMenu;
    MainMenuView mainMenuView;
    MainMenuCommands mainMenuCommands;

    public MainMenuController(MainMenu mainMenu, MainMenuView mainMenuView, MainMenuCommands mainMenuCommands) {
        this.mainMenu = mainMenu;
        this.mainMenuView = mainMenuView;
        this.mainMenuCommands = mainMenuCommands;
    }

    public MainMenu getMainMenu(){return  this.mainMenu;}

    public void draw(Screen screen) {
        mainMenuView.draw(screen);
    }

    public void getNextCommand(Screen screen, GameController gameController) throws IOException { mainMenuView.getNextCommand(screen, mainMenuCommands, gameController);}
}
