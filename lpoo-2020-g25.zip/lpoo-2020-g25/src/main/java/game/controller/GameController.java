package game.controller;

import game.factory.stateFactory.StateFactory;
import game.model.Game;
import game.model.State.State;
import game.view.GameView;

import java.io.IOException;


public class GameController {
    private Game game;

    private GameView gameView;

    private StateController stateController;
    private ArenaController arenaController;

    public GameController(Game game, StateController stateController, GameView gameView) {
        this.game = game;
        this.gameView = gameView;
        this.stateController = stateController;
    }

    public void setControllerState(StateController stateController){this.stateController = stateController;}

    public StateController getControllerState(){return stateController;}

    public ArenaController getArenaController(){return arenaController;}

    public Game getGame(){return this.game;}

    public void changeArenas(ArenaController arenaController){
        this.arenaController = arenaController;
        game.setArena(arenaController.getArena());
    }

    public void changeStates(StateFactory stateFactory){
        State state = stateFactory.createState(this);
        game.setState(state);
        setControllerState(stateFactory.createStateController(this, state));
    }

    public boolean arenaElementsArenaMoving(){return arenaController.getArena().isMovingObjects();}

    public void run() throws IOException {
        gameView.draw(getControllerState());

        while(!game.getFinish())
            gameView.getNextCommand(stateController, this);

        gameView.endGame();
    }

    public void gameHasChanged() {
        try {
            gameView.draw(getControllerState());
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public boolean newRecordBeaten(){
        return this.game.getLeaderBoard().newRecordBeaten(game.getScore());
    }
}
