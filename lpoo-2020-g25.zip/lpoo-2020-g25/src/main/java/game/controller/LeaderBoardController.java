package game.controller;

import com.googlecode.lanterna.screen.Screen;
import game.commands.LeaderBoardCommands;
import game.model.State.LeaderBoard;
import game.view.LeaderBoardView;

import java.io.IOException;

public class LeaderBoardController implements StateController {

    private LeaderBoardView leaderBoardView;
    private LeaderBoardCommands leaderBoardCommands;
    private LeaderBoard leaderBoard;

    public LeaderBoardController(LeaderBoardView leaderBoardView,LeaderBoardCommands leaderBoardCommands,LeaderBoard leaderBoard) {
        this.leaderBoardView = leaderBoardView;
        this.leaderBoardCommands = leaderBoardCommands;
        this.leaderBoard = leaderBoard;
    }

    public LeaderBoard getLeaderBoard() {
        return leaderBoard;
    }

    @Override
    public void getNextCommand(Screen screen, GameController gameController) throws IOException {
        leaderBoardView.getNextCommand(screen,leaderBoardCommands,gameController);
    }

    @Override
    public void draw(Screen screen) {
      leaderBoardView.draw(screen);
    }
}
