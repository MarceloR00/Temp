package game.controller;

import com.googlecode.lanterna.screen.Screen;
import game.commands.LevelTransactionCommands;
import game.model.State.LevelTransaction;
import game.view.LevelTransactionView;

import java.io.IOException;

public class LevelTransactionController implements StateController{
    LevelTransaction levelTransaction;
    LevelTransactionView levelTransactionView;
    LevelTransactionCommands levelTransactionCommands;

    private long frames;

    public LevelTransactionController(LevelTransaction levelTransaction, LevelTransactionView levelTransactionView, LevelTransactionCommands levelTransactionCommands) {
        this.levelTransaction = levelTransaction;
        this.levelTransactionView = levelTransactionView;
        this.levelTransactionCommands = levelTransactionCommands;
        this.frames = 0;
    }

    public long getFrames(){return this.frames;}

    public void incFrames(){this.frames++;}

    public LevelTransaction getLevelTransaction(){return levelTransaction;}

    public void getNextCommand(Screen screen, GameController gameController) throws IOException { levelTransactionView.getNextCommand(screen, levelTransactionCommands, gameController);}

    public void draw(Screen screen) {
        levelTransactionView.draw(screen);
    }
}
