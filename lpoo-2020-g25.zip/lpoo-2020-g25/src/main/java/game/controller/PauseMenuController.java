package game.controller;

import com.googlecode.lanterna.screen.Screen;
import game.commands.PauseMenuCommands;
import game.model.State.PauseMenu;
import game.view.PauseMenuView;

import java.io.IOException;

public class PauseMenuController implements StateController {
    PauseMenu pauseMenu;
    PauseMenuView pauseMenuView;
    PauseMenuCommands pauseMenuCommands;

    public PauseMenuController(PauseMenu pauseMenu, PauseMenuView pauseMenuView, PauseMenuCommands pauseMenuCommands) {
        this.pauseMenu = pauseMenu;
        this.pauseMenuView = pauseMenuView;
        this.pauseMenuCommands = pauseMenuCommands;
    }

    public PauseMenu getPauseMenu(){return  this.pauseMenu;}

    public void draw(Screen screen) {
        pauseMenuView.draw(screen);
    }

    public void getNextCommand(Screen screen, GameController gameController) throws IOException { pauseMenuView.getNextCommand(screen, pauseMenuCommands, gameController);}
}
