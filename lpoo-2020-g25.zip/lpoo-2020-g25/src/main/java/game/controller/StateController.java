package game.controller;

import com.googlecode.lanterna.screen.Screen;

import java.io.IOException;

public interface StateController {
    void getNextCommand(Screen screen, GameController gameController) throws IOException;
    void draw(Screen screen);
}
