package game;

public class ThreadsFunctionsInSnake {
    public ThreadsFunctionsInSnake() {}

    public void makeThreadSleep(long time){
        try{
            Thread.sleep(time);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }
}
