package game.commands;

import game.controller.GameController;
import game.controller.LoseMenuController;
import game.factory.stateFactory.LevelTransactionFactory;

public class LoseMenuCommands implements Commands {
    public void arrowUp(GameController gameController) {
        if (((LoseMenuController) gameController.getControllerState()).getLoseMenu().getHighlighted() == 1)
            ((LoseMenuController) gameController.getControllerState()).getLoseMenu().setHighlighted(2);
        else
            ((LoseMenuController) gameController.getControllerState()).getLoseMenu().setHighlighted(((LoseMenuController) gameController.getControllerState()).getLoseMenu().getHighlighted() - 1);
        gameController.gameHasChanged();
    }

    public void arrowDown(GameController gameController) {
        if (((LoseMenuController) gameController.getControllerState()).getLoseMenu().getHighlighted() == 2)
            ((LoseMenuController) gameController.getControllerState()).getLoseMenu().setHighlighted(1);
        else
            ((LoseMenuController) gameController.getControllerState()).getLoseMenu().setHighlighted(((LoseMenuController) gameController.getControllerState()).getLoseMenu().getHighlighted() + 1);
        gameController.gameHasChanged();
    }

    public void enter(GameController gameController) {
        if (((LoseMenuController) gameController.getControllerState()).getLoseMenu().getHighlighted() == 1) {
            gameController.getGame().setLevel(1);
            gameController.getGame().resetScore();
            gameController.changeStates(new LevelTransactionFactory());
        } else
            gameController.getGame().setFinish(true);
        gameController.gameHasChanged();
    }

    public void exit(GameController gameController) {
        gameController.getGame().setFinish(true);
        gameController.gameHasChanged();
    }
}
