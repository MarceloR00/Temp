package game.commands;

import game.controller.GameController;
import game.controller.LeaderBoardController;
import game.controller.LoseMenuController;
import game.factory.stateFactory.LoseMenuFactory;
import game.factory.stateFactory.MainMenuFactory;

public class LeaderBoardCommands implements Commands{
    @Override
    public void enter(GameController gameController) {
        if(!((LeaderBoardController)gameController.getControllerState()).getLeaderBoard().getIsReadOnly()){
            ((LeaderBoardController)gameController.getControllerState()).getLeaderBoard().setIsReadOnly(true);
            ((LeaderBoardController)gameController.getControllerState()).getLeaderBoard().saveNewScore();
            gameController.gameHasChanged();
            return;
        }
        if (((LeaderBoardController)gameController.getControllerState()).getLeaderBoard().getIsNewRecord()){
            ((LeaderBoardController)gameController.getControllerState()).getLeaderBoard().setIsNewRecord(false);
            gameController.changeStates(new LoseMenuFactory());
        }else
            gameController.changeStates(new MainMenuFactory());
        gameController.gameHasChanged();
    }

    @Override
    public void exit(GameController gameController) {
        gameController.getGame().setFinish(true);
        gameController.gameHasChanged();
    }

    @Override
    public void backSpace(GameController gameController) {
        if(!((LeaderBoardController)gameController.getControllerState()).getLeaderBoard().getIsReadOnly()){
            ((LeaderBoardController)gameController.getControllerState()).getLeaderBoard().eraseLastCharFromNewMember();
            gameController.gameHasChanged();
        }
    }

    @Override
    public void character(GameController gameController, Character character) {
        if(!((LeaderBoardController)gameController.getControllerState()).getLeaderBoard().getIsReadOnly()){
            ((LeaderBoardController)gameController.getControllerState()).getLeaderBoard().writeToNewMember(character);
            gameController.gameHasChanged();
        }
    }
}
