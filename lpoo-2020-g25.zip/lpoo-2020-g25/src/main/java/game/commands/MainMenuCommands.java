package game.commands;

import game.controller.GameController;
import game.controller.MainMenuController;
import game.factory.stateFactory.LeaderBoardFactory;
import game.factory.stateFactory.LevelTransactionFactory;

public class MainMenuCommands implements Commands{
    public void arrowUp(GameController gameController) {
        if(((MainMenuController)gameController.getControllerState()).getMainMenu().getHighlighted() == 1)
            ((MainMenuController)gameController.getControllerState()).getMainMenu().setHighlighted(3);
        else
            ((MainMenuController)gameController.getControllerState()).getMainMenu().setHighlighted(((MainMenuController)gameController.getControllerState()).getMainMenu().getHighlighted()-1);
        gameController.gameHasChanged();
    }

    public void arrowDown(GameController gameController) {
        if(((MainMenuController)gameController.getControllerState()).getMainMenu().getHighlighted() == 3)
            ((MainMenuController)gameController.getControllerState()).getMainMenu().setHighlighted(1);
        else
            ((MainMenuController)gameController.getControllerState()).getMainMenu().setHighlighted(((MainMenuController)gameController.getControllerState()).getMainMenu().getHighlighted()+1);
        gameController.gameHasChanged();
    }

    public void enter(GameController gameController) {
        if(((MainMenuController)gameController.getControllerState()).getMainMenu().getHighlighted() == 1) {
            gameController.getGame().setLevel(1);
            gameController.changeStates(new LevelTransactionFactory());
        }
        else if(((MainMenuController)gameController.getControllerState()).getMainMenu().getHighlighted() == 2) {
            gameController.changeStates(new LeaderBoardFactory());
        }else
            gameController.getGame().setFinish(true);
        gameController.gameHasChanged();
    }

    public void exit(GameController gameController) {
        gameController.getGame().setFinish(true);
        gameController.gameHasChanged();
    }
}
