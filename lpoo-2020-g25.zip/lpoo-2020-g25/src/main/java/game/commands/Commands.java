package game.commands;

import game.controller.GameController;

public interface Commands {
    default void arrowUp(GameController gameController){}
    default void arrowDown(GameController gameController){}
    default void arrowLeft(GameController gameController){}
    default void arrowRight(GameController gameController){}
    default void enter(GameController gameController){}
    default void esc(GameController gameController){}
    default void exit(GameController gameController){}
    default void none(GameController gameController){}
    default void backSpace(GameController gameController){}
    default void character(GameController gameController,Character character){}
}
