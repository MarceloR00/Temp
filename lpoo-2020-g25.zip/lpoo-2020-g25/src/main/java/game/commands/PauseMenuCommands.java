package game.commands;

import game.controller.GameController;
import game.controller.PauseMenuController;
import game.factory.stateFactory.BackArenaFactory;
import game.factory.stateFactory.LevelTransactionFactory;
import game.factory.stateFactory.MainMenuFactory;

public class PauseMenuCommands implements Commands{
    public void arrowUp(GameController gameController) {
        if(((PauseMenuController)gameController.getControllerState()).getPauseMenu().getHighlighted() == 1)
            ((PauseMenuController)gameController.getControllerState()).getPauseMenu().setHighlighted(4);
        else
            ((PauseMenuController)gameController.getControllerState()).getPauseMenu().setHighlighted(((PauseMenuController)gameController.getControllerState()).getPauseMenu().getHighlighted()-1);
        gameController.gameHasChanged();
    }

    public void arrowDown(GameController gameController) {
        if(((PauseMenuController)gameController.getControllerState()).getPauseMenu().getHighlighted() == 4)
            ((PauseMenuController)gameController.getControllerState()).getPauseMenu().setHighlighted(1);
        else
            ((PauseMenuController)gameController.getControllerState()).getPauseMenu().setHighlighted(((PauseMenuController)gameController.getControllerState()).getPauseMenu().getHighlighted()+1);
        gameController.gameHasChanged();
    }

    public void enter(GameController gameController) {
        if(((PauseMenuController)gameController.getControllerState()).getPauseMenu().getHighlighted() == 1)
            gameController.changeStates(new BackArenaFactory());
        else if(((PauseMenuController)gameController.getControllerState()).getPauseMenu().getHighlighted() == 2){
            gameController.getGame().resetScore();
            gameController.changeStates(new LevelTransactionFactory());
        } else if(((PauseMenuController)gameController.getControllerState()).getPauseMenu().getHighlighted() == 3){
            gameController.getGame().resetScore();
            gameController.changeStates(new MainMenuFactory());
        } else
            gameController.getGame().setFinish(true);
        gameController.gameHasChanged();
    }

    public void esc(GameController gameController) {
        gameController.changeStates(new BackArenaFactory());
        gameController.gameHasChanged();
    }

    public void exit(GameController gameController) {
        gameController.getGame().setFinish(true);
        gameController.gameHasChanged();
    }
}
