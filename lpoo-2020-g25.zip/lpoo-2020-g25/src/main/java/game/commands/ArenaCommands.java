package game.commands;

import game.ThreadsFunctionsInSnake;
import game.controller.GameController;
import game.factory.stateFactory.PauseMenuFactory;
import game.model.Direction.*;

public class ArenaCommands implements Commands{
    public void arrowUp(GameController gameController) {
        if(gameController.getArenaController().getArena().isMovingObjects() && !gameController.getArenaController().getArena().getSnake().getDirection().isUp() && !gameController.getArenaController().getArena().getSnake().getDirection().isDown())
            gameController.getArenaController().updateArena(gameController, gameController.getArenaController().getArena().getSnake().upPosition(), new UpDirection());
        else if(!gameController.getArenaController().getArena().isMovingObjects())
            gameController.getArenaController().defineSnakeDirection(new UpDirection());
        gameController.getArenaController().setFrames(0);
        gameController.gameHasChanged();
    }

    public void arrowDown(GameController gameController) {
        if(gameController.getArenaController().getArena().isMovingObjects() && !gameController.getArenaController().getArena().getSnake().getDirection().isDown() && !gameController.getArenaController().getArena().getSnake().getDirection().isUp())
            gameController.getArenaController().updateArena(gameController, gameController.getArenaController().getArena().getSnake().downPosition(), new DownDirection());
        else if(!gameController.getArenaController().getArena().isMovingObjects())
            gameController.getArenaController().defineSnakeDirection(new DownDirection());
        gameController.getArenaController().setFrames(0);
        gameController.gameHasChanged();
    }

    public void arrowLeft(GameController gameController) {
        if(gameController.getArenaController().getArena().isMovingObjects() && !gameController.getArenaController().getArena().getSnake().getDirection().isLeft() && !gameController.getArenaController().getArena().getSnake().getDirection().isRight())
            gameController.getArenaController().updateArena(gameController, gameController.getArenaController().getArena().getSnake().leftPosition(), new LeftDirection());
        else if(!gameController.getArenaController().getArena().isMovingObjects())
            gameController.getArenaController().defineSnakeDirection(new LeftDirection());
        gameController.getArenaController().setFrames(0);
        gameController.gameHasChanged();
    }

    public void arrowRight(GameController gameController) {
        if(gameController.getArenaController().getArena().isMovingObjects() && !gameController.getArenaController().getArena().getSnake().getDirection().isRight() && !gameController.getArenaController().getArena().getSnake().getDirection().isLeft())
            gameController.getArenaController().updateArena(gameController, gameController.getArenaController().getArena().getSnake().rightPosition(), new RightDirection());
        else if(!gameController.getArenaController().getArena().isMovingObjects())
            gameController.getArenaController().defineSnakeDirection(new RightDirection());
        gameController.getArenaController().setFrames(0);
        gameController.gameHasChanged();
    }

    public void esc(GameController gameController) {
        gameController.changeStates(new PauseMenuFactory());
        gameController.gameHasChanged();
    }

    public void exit(GameController gameController) {
        if(gameController.getArenaController().getArena().isMovingObjects())
            gameController.getGame().setFinish(true);
        gameController.gameHasChanged();
    }

    public void none(GameController gameController) {
        gameController.getArenaController().incFrames();

        if (gameController.getArenaController().getFrames() % 5 == 0 && gameController.getArenaController().getArena().isMovingObjects()) {
            gameController.getArenaController().updateArena(gameController, gameController.getArenaController().getArena().getSnake().getNextPosition(), new NullDirection());
            gameController.gameHasChanged();
        }
        new ThreadsFunctionsInSnake().makeThreadSleep(1000/60);
    }
}
