package game.commands;

import game.ThreadsFunctionsInSnake;
import game.controller.ArenaController;
import game.controller.GameController;
import game.controller.LevelTransactionController;
import game.factory.stateFactory.ArenaFactory;

public class LevelTransactionCommands implements Commands{
    public void exit(GameController gameController) {
        gameController.getGame().setFinish(true);
        gameController.gameHasChanged();
    }

    public void none(GameController gameController) {
        ((LevelTransactionController)gameController.getControllerState()).incFrames();

        if(((LevelTransactionController)gameController.getControllerState()).getFrames() == 120){
            gameController.changeStates(new ArenaFactory());
            gameController.changeArenas((ArenaController) gameController.getControllerState());
            gameController.gameHasChanged();
        }
        new ThreadsFunctionsInSnake().makeThreadSleep(1000/60);
        gameController.gameHasChanged();
    }
}
