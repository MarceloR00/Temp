package game.view;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.screen.Screen;
import game.commands.ArenaCommands;
import game.commands.PauseMenuCommands;
import game.controller.GameController;
import game.model.State.PauseMenu;

import java.io.IOException;

public class PauseMenuView {
    PauseMenu pauseMenu;

    public PauseMenuView(PauseMenu pauseMenu) {
        this.pauseMenu = pauseMenu;
    }


    public void draw(Screen screen) {
        TextGraphics graphics = screen.newTextGraphics();
        graphics.setBackgroundColor(TextColor.Factory.fromString("#000000"));
        graphics.setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        graphics.putString(pauseMenu.getPosition().getX(), pauseMenu.getPosition().getY()+2, "PAUSE MENU");
        graphics.putString(pauseMenu.getPosition().getX() + 2, pauseMenu.getPosition().getY() + 4, "Resume");
        graphics.putString(pauseMenu.getPosition().getX() + 2, pauseMenu.getPosition().getY() + 5, "Restart");
        graphics.putString(pauseMenu.getPosition().getX() + 2, pauseMenu.getPosition().getY() + 6, "MainMenu");
        graphics.putString(pauseMenu.getPosition().getX() + 2, pauseMenu.getPosition().getY() + 7, "Exit");

        graphics.setBackgroundColor(TextColor.Factory.fromString("#336699"));

        switch (pauseMenu.getHighlighted()){
            case 1:
                graphics.putString(pauseMenu.getPosition().getX() + 2, pauseMenu.getPosition().getY() + 4, "Resume");
                break;
            case 2:
                graphics.putString(pauseMenu.getPosition().getX() + 2, pauseMenu.getPosition().getY() + 5, "Restart");
                break;
            case 3:
                graphics.putString(pauseMenu.getPosition().getX() + 2, pauseMenu.getPosition().getY() + 6, "MainMenu");
                break;
            default:
                graphics.putString(pauseMenu.getPosition().getX() + 2, pauseMenu.getPosition().getY() + 7, "Exit");
        }
    }

    public void getNextCommand(Screen screen, PauseMenuCommands pauseMenuCommands, GameController gameController) throws IOException {
        KeyStroke input = screen.pollInput();

        if(input != null){
            if (input.getKeyType() == KeyType.EOF) pauseMenuCommands.exit(gameController);
            else if (input.getKeyType() == KeyType.Escape) pauseMenuCommands.esc(gameController);
            else if (input.getKeyType() == KeyType.Enter) pauseMenuCommands.enter(gameController);
            else if (input.getKeyType() == KeyType.ArrowDown) pauseMenuCommands.arrowDown(gameController);
            else if (input.getKeyType() == KeyType.ArrowUp) pauseMenuCommands.arrowUp(gameController);
        }
    }
}
