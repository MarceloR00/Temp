package game.view;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.screen.Screen;
import game.commands.ArenaCommands;
import game.commands.MainMenuCommands;
import game.controller.GameController;
import game.model.State.MainMenu;

import java.io.IOException;

public class MainMenuView {
    MainMenu mainMenu;

    public MainMenuView(MainMenu mainMenu) {
        this.mainMenu = mainMenu;
    }

    public void draw(Screen screen){
        TextGraphics graphics = screen.newTextGraphics();
        graphics.setBackgroundColor(TextColor.Factory.fromString("#000000"));
        graphics.setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        drawGroup(graphics);
        graphics.putString(mainMenu.getPosition().getX(), mainMenu.getPosition().getY()+2, "MAIN MENU");
        graphics.putString(mainMenu.getPosition().getX() + 2, mainMenu.getPosition().getY() + 4, "Play");
        graphics.putString(mainMenu.getPosition().getX() -1, mainMenu.getPosition().getY() + 5, "LeaderBoard");
        graphics.putString(mainMenu.getPosition().getX() + 2, mainMenu.getPosition().getY() + 6, "Exit");

        graphics.setBackgroundColor(TextColor.Factory.fromString("#336699"));

        switch (mainMenu.getHighlighted()){
            case 1:
                graphics.putString(mainMenu.getPosition().getX() + 2, mainMenu.getPosition().getY() + 4, "Play");
                break;
            case 2:
                graphics.putString(mainMenu.getPosition().getX() -1, mainMenu.getPosition().getY() + 5, "LeaderBoard");
                break;
            default:
                graphics.putString(mainMenu.getPosition().getX() + 2, mainMenu.getPosition().getY() + 6, "Exit");

        }
    }

    public void drawGroup(TextGraphics graphics){
        graphics.putString(0, 0, "LPOO / 2019-2020");
        graphics.putString(0, 2, "GROUP: 25");
        graphics.putString(0, 3, "Diogo Santos / up201806878");
        graphics.putString(0, 4, "Marcelo Reis / up201809566");
    }

    public void getNextCommand(Screen screen, MainMenuCommands mainMenuCommands, GameController gameController) throws IOException {
        KeyStroke input = screen.pollInput();

        if(input != null){
            if (input.getKeyType() == KeyType.EOF) mainMenuCommands.exit(gameController);
            else if (input.getKeyType() == KeyType.Enter) mainMenuCommands.enter(gameController);
            else if (input.getKeyType() == KeyType.ArrowDown) mainMenuCommands.arrowDown(gameController);
            else if (input.getKeyType() == KeyType.ArrowUp) mainMenuCommands.arrowUp(gameController);
        }
    }
}
