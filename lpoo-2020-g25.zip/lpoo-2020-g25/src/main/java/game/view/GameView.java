package game.view;

import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.screen.TerminalScreen;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.Terminal;
import game.controller.GameController;
import game.controller.StateController;
import game.model.Game;

import java.io.IOException;

public class GameView {
    private final TerminalScreen screen;

    public GameView(TerminalScreen terminalScreen) throws IOException {
        this.screen = terminalScreen;

        this.screen.setCursorPosition(null);   // we don't need a cursor
        this.screen.startScreen();             // screens must be started
        this.screen.doResizeIfNecessary();     // resize screen if necessary

    }

    public void getNextCommand(StateController stateController, GameController gameController) throws IOException {
        stateController.getNextCommand(screen, gameController);
    }

    public void draw(StateController stateController) throws IOException {
        screen.clear();
        stateController.draw(screen);
        screen.refresh();
    }

    public void endGame() throws  IOException{
            screen.close();
    }
}
