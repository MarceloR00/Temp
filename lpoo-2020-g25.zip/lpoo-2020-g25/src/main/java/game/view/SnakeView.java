package game.view;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.screen.Screen;
import game.model.BodyPart;
import game.model.State.ArenaElements.Snake;

import java.util.List;

public class SnakeView {
    Snake snake;

    public SnakeView(Snake snake) {
        this.snake = snake;
    }

    public void draw(Screen screen){
        TextGraphics graphics = screen.newTextGraphics();

        graphics.setBackgroundColor(TextColor.Factory.fromString("#228B22"));
        graphics.setForegroundColor(TextColor.Factory.fromString("#FFFF00"));

        List<BodyPart> snakePosition = snake.getBody();

        for (int i=0;i<snakePosition.size();i++){
            if (i==0)
                graphics.putString(snakePosition.get(i).getPosition().getX(), snakePosition.get(i).getPosition().getY(), "o");
            else
                graphics.putString(snakePosition.get(i).getPosition().getX(), snakePosition.get(i).getPosition().getY(), "+");
        }
    }
}
