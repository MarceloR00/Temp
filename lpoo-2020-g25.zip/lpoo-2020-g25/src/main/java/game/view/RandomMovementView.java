package game.view;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.screen.Screen;
import game.model.Position;

public class RandomMovementView implements StrategyView{

    public RandomMovementView() { }

    @Override
    public void draw(Screen screen, Position position){
        TextGraphics graphics = screen.newTextGraphics();

        graphics.setBackgroundColor(TextColor.Factory.fromString("#228B22"));
        graphics.setForegroundColor(TextColor.Factory.fromString("#0000FF"));

        graphics.putString(position.getX(), position.getY(), "R");

    }
}
