package game.view;

import com.googlecode.lanterna.TerminalPosition;
import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.screen.Screen;
import game.commands.ArenaCommands;
import game.controller.GameController;
import game.model.State.Arena;
import game.model.Position;

import java.io.IOException;
import java.util.List;

public class ArenaView {

    private Arena arena;
    private SnakeView snakeView;
    private EnemieView enemieView;

    public ArenaView(Arena arena, SnakeView snakeView, EnemieView enemieView) {
        this.arena = arena;
        this.snakeView = snakeView;
        this.enemieView = enemieView;
    }

    public void draw(Screen screen) {
        TextGraphics graphics = screen.newTextGraphics();
        graphics.setBackgroundColor(TextColor.Factory.fromString("#228B22"));
        graphics.fillRectangle(
                new TerminalPosition(0, 0),
                new TerminalSize(arena.getWidth(), arena.getHeight()),
                ' '
        );

        snakeView.draw(screen);
        enemieView.draw(screen);
        drawTrees(graphics);
        drawApples(graphics);
        drawArenaInfo(graphics);
    }

    private void drawArenaInfo(TextGraphics graphics){
        graphics.setBackgroundColor(TextColor.Factory.fromString("#000000"));
        graphics.setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        graphics.putString(0, arena.getHeight(), "Level: " + arena.getLevel() + " / Walls: " + arena.getTrees().size() + " / Apples: " + arena.getApples().size() + " / Enemies: " + arena.getEnemies().size());
    }

    private void drawTrees(TextGraphics graphics){
        graphics.setBackgroundColor(TextColor.Factory.fromString("#228B22"));
        graphics.setForegroundColor(TextColor.Factory.fromString("#8B4513"));

        List<Position> trees = arena.getTrees();

        for (Position tree:trees){
            graphics.putString(tree.getX(),tree.getY(), "#");
        }
    }

    private void drawApples(TextGraphics graphics){
        graphics.setBackgroundColor(TextColor.Factory.fromString("#228B22"));
        graphics.setForegroundColor(TextColor.Factory.fromString("#FF0000"));

        List<Position> apples = arena.getApples();

        for (Position apple:apples){
            graphics.putString(apple.getX(),apple.getY(), "ó");
        }
    }

    public void getNextCommand(Screen screen, ArenaCommands arenaCommands, GameController gameController) throws IOException {
        KeyStroke input = screen.pollInput();

        if(input == null)
            arenaCommands.none(gameController);
        else{
            if (input.getKeyType() == KeyType.EOF) arenaCommands.exit(gameController);
            else if (input.getKeyType() == KeyType.Escape) arenaCommands.esc(gameController);
            else if (input.getKeyType() == KeyType.Enter) arenaCommands.enter(gameController);
            else if (input.getKeyType() == KeyType.ArrowDown) arenaCommands.arrowDown(gameController);
            else if (input.getKeyType() == KeyType.ArrowUp) arenaCommands.arrowUp(gameController);
            else if (input.getKeyType() == KeyType.ArrowLeft) arenaCommands.arrowLeft(gameController);
            else if (input.getKeyType() == KeyType.ArrowRight) arenaCommands.arrowRight(gameController);
            else arenaCommands.none(gameController);
        }
    }
}
