package game.view;

import com.googlecode.lanterna.TerminalPosition;
import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.screen.Screen;
import game.commands.LeaderBoardCommands;
import game.controller.GameController;
import game.model.Score;
import game.model.State.LeaderBoard;

import java.io.IOException;

public class LeaderBoardView extends StateView{

    private LeaderBoard leaderBoard;

    public LeaderBoardView(LeaderBoard leaderBoard) {
        this.leaderBoard = leaderBoard;
    }

    public void getNextCommand(Screen screen, LeaderBoardCommands leaderBoardCommands, GameController gameController) throws IOException {
        KeyStroke input = screen.readInput();

        switch (input.getKeyType()){
            case Enter:
                leaderBoardCommands.enter(gameController);
                break;
            case EOF:
                leaderBoardCommands.exit(gameController);
                break;
            case Backspace:
                leaderBoardCommands.backSpace(gameController);
                break;
            case Character:
                leaderBoardCommands.character(gameController,input.getCharacter());
        }
    }

    public void draw(Screen screen){
        TextGraphics graphics = screen.newTextGraphics();
        graphics.setBackgroundColor(TextColor.Factory.fromString("#000000"));
        graphics.setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        graphics.putString(leaderBoard.getPosition().getX()-1, leaderBoard.getPosition().getY()-2, "LEADERBOARD");
        if (leaderBoard.getIsNewRecord())
            graphics.putString(leaderBoard.getPosition().getX()-4, leaderBoard.getPosition().getY(), "NEW RECORD BEATEN");
        graphics.putString(leaderBoard.getPosition().getX()-9, leaderBoard.getPosition().getY()+2, "NickName");
        graphics.putString(leaderBoard.getPosition().getX()+11, leaderBoard.getPosition().getY()+2, "Score");

        for (Score score: leaderBoard.getScores()){
            graphics.putString(
                    leaderBoard.getPosition().getX()-11,
                    leaderBoard.getPosition().getY()+ 3 + score.getPosition(),
                    String.valueOf(score.getPosition())+'.');
            graphics.putString(leaderBoard.getPosition().getX()-9,
                    leaderBoard.getPosition().getY()+ 3 + score.getPosition(),
                    score.getNickName());
            graphics.putString(leaderBoard.getPosition().getX()+11,
                    leaderBoard.getPosition().getY()+ 3 + score.getPosition(),
                    score.getScore());
        }

        if(!leaderBoard.getIsReadOnly()){
            graphics.setBackgroundColor(TextColor.Factory.fromString("#336699"));
            graphics.drawRectangle(new TerminalPosition(leaderBoard.getPosition().getX()-11,
                            leaderBoard.getPosition().getY()+3 +leaderBoard.getNewMemberPosition()),
                    new TerminalSize(27,1),' ');

            graphics.putString(leaderBoard.getPosition().getX()-11,
                    leaderBoard.getPosition().getY()+3+leaderBoard.getNewMemberPosition(),
                    leaderBoard.getNewMemberPosition()+"."+leaderBoard.getNewMember());
            graphics.putString(leaderBoard.getPosition().getX()+11,
                    leaderBoard.getPosition().getY()+ 3 + leaderBoard.getNewMemberPosition(),
                    leaderBoard.getNewMemberScore());
        }
    }
}
