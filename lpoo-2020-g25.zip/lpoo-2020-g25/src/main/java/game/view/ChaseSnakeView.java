package game.view;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.screen.Screen;
import game.model.Position;

public class ChaseSnakeView implements StrategyView{
    public ChaseSnakeView() {}

    public void draw(Screen screen, Position position){
        TextGraphics graphics = screen.newTextGraphics();

        graphics.setBackgroundColor(TextColor.Factory.fromString("#228B22"));
        graphics.setForegroundColor(TextColor.Factory.fromString("#FF00FF"));

        graphics.putString(position.getX(), position.getY(), "C");

    }
}
