package game.view;

import com.googlecode.lanterna.screen.Screen;
import game.factory.strategyViewFactory.StrategyViewFactory;
import game.model.State.ArenaElements.Enemie.Enemie;

import java.util.List;

public class EnemieView {
    List<Enemie> enemies;

    public EnemieView(List<Enemie> enemies) {
        this.enemies = enemies;
    }

    public void draw(Screen screen){
        for (Enemie enemie:enemies)
            new StrategyViewFactory().createStrategyView(enemie.getStrategy()).draw(screen, enemie.getPosition());
    }
}
