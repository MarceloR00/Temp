package game.view;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.screen.Screen;
import game.commands.ArenaCommands;
import game.commands.LevelTransactionCommands;
import game.controller.GameController;
import game.model.State.LevelTransaction;

import java.io.IOException;

public class LevelTransactionView {
    LevelTransaction levelTransaction;

    public LevelTransactionView(LevelTransaction levelTransaction) {
        this.levelTransaction = levelTransaction;
    }

    public void draw(Screen screen) {
        int level = levelTransaction.getLevel();

        TextGraphics graphics = screen.newTextGraphics();
        graphics.setBackgroundColor(TextColor.Factory.fromString("#000000"));
        graphics.setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        if(level > 1){
            graphics.putString(levelTransaction.getPosition().getX() - 3, levelTransaction.getPosition().getY()+1, "LEVEL PASSED");
            graphics.putString(levelTransaction.getPosition().getX() - 3, levelTransaction.getPosition().getY()+3, "NEXT LEVEL " + level);
        }
        else
            graphics.putString(levelTransaction.getPosition().getX(), levelTransaction.getPosition().getY()+3, "LEVEL " + level);
        graphics.putString(levelTransaction.getPosition().getX()-14, levelTransaction.getPosition().getY()+5, "Walls: " + 20 * level + " / Apples: " + 5 * level + " / Enemies: " + 5 * level);

    }

    public void getNextCommand(Screen screen, LevelTransactionCommands levelTransactionCommands, GameController gameController) throws IOException {
        KeyStroke input = screen.pollInput();

        if(input == null)
            levelTransactionCommands.none(gameController);
        else{
            if (input.getKeyType() == KeyType.EOF) levelTransactionCommands.exit(gameController);
            else levelTransactionCommands.none(gameController);
        }
    }
}
