package game.view;

public class StateView {}
