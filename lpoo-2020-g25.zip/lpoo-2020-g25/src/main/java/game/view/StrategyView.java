package game.view;

import com.googlecode.lanterna.screen.Screen;
import game.model.Position;

public interface StrategyView {
    void draw(Screen screen, Position position);
}
