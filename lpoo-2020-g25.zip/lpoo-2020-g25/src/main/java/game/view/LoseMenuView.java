package game.view;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.screen.Screen;
import game.commands.ArenaCommands;
import game.commands.LoseMenuCommands;
import game.controller.GameController;
import game.model.State.LoseMenu;

import java.io.IOException;

public class LoseMenuView {
    LoseMenu loseMenu;

    public LoseMenuView(LoseMenu loseMenu) {
        this.loseMenu = loseMenu;
    }

    public void draw(Screen screen) {
        TextGraphics graphics = screen.newTextGraphics();
        graphics.setBackgroundColor(TextColor.Factory.fromString("#000000"));
        graphics.setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        graphics.putString(loseMenu.getPosition().getX(), loseMenu.getPosition().getY()+2, "YOU LOSE");
        graphics.putString(loseMenu.getPosition().getX() - 1, loseMenu.getPosition().getY() + 4, "Play Again");
        graphics.putString(loseMenu.getPosition().getX() + 2, loseMenu.getPosition().getY() + 5, "Exit");

        graphics.setBackgroundColor(TextColor.Factory.fromString("#336699"));

        switch (loseMenu.getHighlighted()){
            case 1:
                graphics.putString(loseMenu.getPosition().getX() - 1, loseMenu.getPosition().getY() + 4, "Play Again");
                break;
            default:
                graphics.putString(loseMenu.getPosition().getX() + 2, loseMenu.getPosition().getY() + 5, "Exit");
        }
    }

    public void getNextCommand(Screen screen, LoseMenuCommands loseMenuCommands, GameController gameController) throws IOException {
        KeyStroke input = screen.pollInput();

        if(input != null) {
            if (input.getKeyType() == KeyType.EOF) loseMenuCommands.exit(gameController);
            else if (input.getKeyType() == KeyType.Enter) loseMenuCommands.enter(gameController);
            else if (input.getKeyType() == KeyType.ArrowDown) loseMenuCommands.arrowDown(gameController);
            else if (input.getKeyType() == KeyType.ArrowUp) loseMenuCommands.arrowUp(gameController);
        }
    }
}
