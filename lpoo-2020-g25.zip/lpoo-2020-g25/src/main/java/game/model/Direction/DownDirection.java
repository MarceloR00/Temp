package game.model.Direction;

import game.model.Position;

public class DownDirection implements Direction {
    public Position getOpositePosition(Position position) {
        return position.upPosition();
    }
    public Position getNextPosition(Position position) { return position.downPosition();}

    public boolean isNull() {
        return false;
    }
    public boolean isRight() {
        return false;
    }
    public boolean isLeft() {
        return false;
    }
    public boolean isDown() {
        return true;
    }
    public boolean isUp() {
        return false;
    }

    public Direction copy() {
        return new DownDirection();
    }
}
