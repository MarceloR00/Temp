package game.model.Direction;

import game.model.Position;

public class UpDirection implements Direction {
    public Position getOpositePosition(Position position) {
        return position.downPosition();
    }
    public Position getNextPosition(Position position) {
        return position.upPosition();
    }

    public boolean isNull() {
        return false;
    }
    public boolean isRight() {
        return false;
    }
    public boolean isLeft() {
        return false;
    }
    public boolean isDown() {
        return false;
    }
    public boolean isUp() {
        return true;
    }

    public Direction copy() {
        return new UpDirection();
    }
}
