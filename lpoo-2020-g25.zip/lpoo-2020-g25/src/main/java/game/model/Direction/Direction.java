package game.model.Direction;

import game.model.Position;

public interface Direction {
    Position getOpositePosition(Position position);
    Position getNextPosition(Position position);

    boolean isNull();
    boolean isRight();
    boolean isLeft();
    boolean isDown();
    boolean isUp();

    Direction copy();
}
