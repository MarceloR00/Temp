package game.model.Direction;

import game.model.Position;

public class NullDirection implements Direction {
    public Position getOpositePosition(Position position) {
        return null;
    }
    public Position getNextPosition(Position position) {
        return null;
    }

    public boolean isNull() {
        return true;
    }
    public boolean isRight() {
        return false;
    }
    public boolean isLeft() {
        return false;
    }
    public boolean isDown() {
        return false;
    }
    public boolean isUp() {
        return false;
    }

    public Direction copy() {
        return new NullDirection();
    }
}
