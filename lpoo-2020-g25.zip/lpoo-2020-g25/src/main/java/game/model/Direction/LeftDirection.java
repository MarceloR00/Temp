package game.model.Direction;

import game.model.Position;

public class LeftDirection implements Direction {
    public Position getOpositePosition(Position position) {
        return position.rightPosition();
    }
    public Position getNextPosition(Position position) {
        return position.leftPosition();
    }

    public boolean isNull() {
        return false;
    }
    public boolean isRight() {
        return false;
    }
    public boolean isLeft() {
        return true;
    }
    public boolean isDown() {
        return false;
    }
    public boolean isUp() {
        return false;
    }

    public Direction copy() {
        return new LeftDirection();
    }
}
