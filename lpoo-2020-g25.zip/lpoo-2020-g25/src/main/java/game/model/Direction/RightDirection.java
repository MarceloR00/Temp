package game.model.Direction;

import game.model.Position;

public class RightDirection implements Direction {
    public Position getOpositePosition(Position position) {
        return position.leftPosition();
    }
    public Position getNextPosition(Position position) {
        return position.rightPosition();
    }

    public boolean isNull() {
        return false;
    }
    public boolean isRight() {
        return true;
    }
    public boolean isLeft() {
        return false;
    }
    public boolean isDown() {
        return false;
    }
    public boolean isUp() {
        return false;
    }

    public Direction copy() {
        return new RightDirection();
    }
}
