package game.model;

import game.model.Direction.Direction;

import java.util.ArrayList;
import java.util.List;

public class BodyPart {
    private Position position;
    private Direction direction;

    private int queue;

    private List<ChangeDirection> changeDirections = new ArrayList<>();

    public BodyPart(Position position, Direction direction) {
        this.position = position;
        this.direction = direction;
        this.queue = 0;
    }

    public BodyPart(Position position) {
        this.position = position;
    }

    public BodyPart(Position position, Direction direction,int queue) {
        this.position = position;
        this.direction = direction;
        this.queue = queue;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    public List<ChangeDirection> getChangeDirections() {
        return changeDirections;
    }

    public void setChangeDirections(List<ChangeDirection> changeDirections) {
        this.changeDirections = changeDirections;
    }

    public void goNextPosition(){
        if (queue != 0){
            queue--;
            return;
        }

        verifyDirection();

        Position position1 = direction.getNextPosition(position);
        position.setX(position1.getX());
        position.setY(position1.getY());
    }

    public void addChangeDirections(Position position, Direction direction){
        changeDirections.add(new ChangeDirection(position,direction));
    }

    private void verifyDirection(){
        if (!changeDirections.isEmpty() && position.equals(changeDirections.get(0).getPosition())){
            this.direction = changeDirections.get(0).getDirection();
            changeDirections.remove(0);
        }
    }

    public Position predictNextPosition(){
        if(queue != 0)
            return position;

        return direction.getNextPosition(position);
    }

}
