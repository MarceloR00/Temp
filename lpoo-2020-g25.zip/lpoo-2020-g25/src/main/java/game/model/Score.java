package game.model;

public class Score {
    int position;
    String nickName;
    String score;

    public Score(int position, String nickName, String score) {
        this.position = position;
        this.nickName = nickName;
        this.score = score;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }
}
