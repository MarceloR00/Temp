package game.model.State.ArenaElements.Enemie;

import game.model.Position;
import game.model.State.Arena;
import game.view.StrategyView;

public class Enemie {
    Position position;
    Arena arena;

    Strategy strategy;

    public Enemie(Position position, Arena arena, Strategy strategy) {
        this.position = position;
        this.arena = arena;
        this.strategy = strategy;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public Position getNextPosition(){return strategy.getNextPosition(position);}

    public Strategy getStrategy(){return this.strategy;}
}
