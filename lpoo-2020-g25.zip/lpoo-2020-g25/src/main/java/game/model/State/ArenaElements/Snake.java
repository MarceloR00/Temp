package game.model.State.ArenaElements;

import game.model.BodyPart;
import game.model.Direction.Direction;
import game.model.Position;

import java.util.ArrayList;
import java.util.List;

public class Snake {
    private Position initialPosition;

    private List<BodyPart> body = new ArrayList<>();

    public Snake(Position position) {
        this.initialPosition = position;

        this.body.add(new BodyPart(position));
    }

    public int getSnakeSize(){return body.size();}

    public List<BodyPart> getBody() {
        return body;
    }

    public Position getInitialPosition() {
        return initialPosition;
    }

    public Position upPosition() {
        return getHeadOfSnake().getPosition().upPosition();
    }

    public Position downPosition() {
        return getHeadOfSnake().getPosition().downPosition();
    }

    public Position rightPosition() {
        return getHeadOfSnake().getPosition().rightPosition();
    }

    public Position leftPosition() {
        return getHeadOfSnake().getPosition().leftPosition();
    }

    public Direction getDirection() {
        return getHeadOfSnake().getDirection();
    }

    public BodyPart getHeadOfSnake(){
        return body.get(0);
    }

    public BodyPart getTailOfSnake(){ return body.get(body.size()-1);}

    public Position getNextPosition() {
        return getHeadOfSnake().predictNextPosition();
    }

    public void setInitialDirection(Direction direction){
        body.get(0).setDirection(direction);
        buildSnake(direction);
    }

    public Position copyLastPosition(){ return new Position(getTailOfSnake().getPosition().getX(),getTailOfSnake().getPosition().getY()); }

    public Direction copyLastDirection(){
        return  getTailOfSnake().getDirection().copy();
    }

    public void addNewBodyPart(BodyPart newBodyPart){ body.add(newBodyPart); }

    private void buildSnake(Direction direction){
        body.add(new BodyPart(new Position(initialPosition.getX(), initialPosition.getY()), direction.copy(),1));
        body.add(new BodyPart(new Position(initialPosition.getX(), initialPosition.getY()), direction.copy(),2));
        body.add(new BodyPart(new Position(initialPosition.getX(), initialPosition.getY()), direction.copy(),3));
        body.add(new BodyPart(new Position(initialPosition.getX(), initialPosition.getY()), direction.copy(),4));
    }

    public boolean collisionWithEnemieAt(Position position){
        for(BodyPart bodyPart:body){
            if(bodyPart.getPosition().equals(position))
                return true;
        }
        return false;
    }

    public boolean BodyPartInThatPosition(Position position){
        for (int i=0;i<body.size();i++){
            if (i!=0 && body.get(i).predictNextPosition().equals(position))
                return true;
        }
        return false;
    }
}