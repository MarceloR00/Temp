package game.model.State;

import game.model.Position;
import game.model.State.Menu;

public class LevelTransaction extends Menu {

    private int level;

    public LevelTransaction(Position position, int level) {
        super(position);
        this.level = level;
    }

    public int getLevel() {
        return level;
    }
}
