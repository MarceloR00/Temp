package game.model.State.ArenaElements.Enemie;

import game.model.Position;
import game.view.StrategyView;

import static java.lang.StrictMath.abs;

public class ChaseSnakeStrategy implements Strategy {

    Position headOfSnake;
    StrategyView strategyView;

    int frames;
    int direction;

    public ChaseSnakeStrategy(Position headOfSnake, StrategyView strategyView) {
        this.headOfSnake = headOfSnake;
        this.strategyView = strategyView;
        this.frames = -1;
        this.direction = 0;
    }

    public Position getNextPosition(Position position) {
        frames++;
        if(frames % 2 == 0) {
            int x = position.getX() - headOfSnake.getX();
            int y = position.getY() - headOfSnake.getY();

            if (x != 0)
                x = x / abs(x);

            if (y != 0)
                y = y / abs(y);

            //impede que se movam na diagonal
            if (x != 0 && y != 0){
                if(direction % 2 == 0)
                    y = 0; //horizontal
                else
                    x = 0;  //vertical
            }

            direction++;

            return new Position(position.getX() - x, position.getY() - y);
        }
        return position;
    }
}
