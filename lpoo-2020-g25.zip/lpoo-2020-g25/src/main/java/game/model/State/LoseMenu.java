package game.model.State;

import game.model.Position;
import game.model.State.Menu;

public class LoseMenu extends Menu {

    public LoseMenu(Position position) {
        super(position);
    }
}
