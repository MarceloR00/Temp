package game.model.State.ArenaElements.Enemie;

import game.model.Position;
import game.view.StrategyView;

public interface Strategy {
    Position getNextPosition(Position position);
}
