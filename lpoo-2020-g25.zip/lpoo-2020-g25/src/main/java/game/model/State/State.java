package game.model.State;

public interface State {}
