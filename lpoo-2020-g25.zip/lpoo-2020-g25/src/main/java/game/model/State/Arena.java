package game.model.State;

import game.factory.stateFactory.LoseMenuFactory;
import game.model.State.ArenaElements.Enemie.Enemie;
import game.model.Position;
import game.model.State.ArenaElements.Snake;

import java.util.ArrayList;
import java.util.List;

public class Arena implements State {

    private int width;
    private int height;
    private int level;

    //antes de o utilizador escolher a direcao da snake
    //este parametro encontra-se a false, depois encontra-se sempre a true
    private boolean movingObjects;

    Snake snake;

    private List<Position> trees;
    private List<Position> apples;

    private List<Enemie> enemies;

    public Arena(int width, int height,int level,Snake snake) {
        this.width = width;
        this.height = height;
        this.level = level;

        this.movingObjects = false;

        this.snake = snake;

        this.trees = new ArrayList<>();
        this.apples = new ArrayList<>();
        this.enemies = new ArrayList<>();
    }

    public int getLevel() { return level; }

    public boolean isMovingObjects() {
        return movingObjects;
    }

    public void setMovingObjects(boolean movingObjects) {
        this.movingObjects = movingObjects;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public Snake getSnake(){return this.snake;}

    public List<Position> getTrees(){return this.trees;}

    public List<Position> getApples(){return this.apples;}

    public List<Enemie> getEnemies(){return this.enemies;}

    public void addTree(Position position){trees.add(position);}

    public void addApple(Position position){apples.add(position);}

    public void addEnemie(Enemie enemie){enemies.add(enemie);}

    public boolean canMoveTo(Position position) {
        if(passTheLimitsOfArena(position) || TreeInThatPosition(position))
            return false;

        return true;
    }

    public boolean arenaContainObjectInPosition(Position position){
        if(passTheLimitsOfArena(position) || TreeInThatPosition(position) || AppleInThatPosition(position) || EnemieInThatPosition(position))
            return true;

        return false;
    }

    public boolean TreeInThatPosition(Position position){
        for(Position tree:trees){
            if(tree.equals(position))
                return true;
        }
        return false;
    }

    public boolean AppleInThatPosition(Position position){
        for(Position apple:apples){
            if(apple.equals(position))
                return true;
        }
        return false;
    }

    public boolean EnemieInThatPosition(Position position){
        for(Enemie enemie:enemies){
            if(enemie.getPosition().equals(position))
                return true;
        }
        return false;
    }

    public boolean verifyLevelPassed(){return apples.size() == 0;}

    public boolean verifyLevelLost(){
        for(Enemie enemie:enemies){
            if(snake.BodyPartInThatPosition(enemie.getPosition()))
                return true;
        }
        return false;
    }

    private boolean passTheLimitsOfArena(Position position){
        if (position.getY() <= -1 || position.getY() >= height || position.getX() <= -1 || position.getX() >= width)
            return true;
        return false;
    }
}
