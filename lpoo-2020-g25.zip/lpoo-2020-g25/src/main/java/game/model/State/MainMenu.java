package game.model.State;

import game.model.Position;
import game.model.State.Menu;

public class MainMenu extends Menu {

    public MainMenu(Position position) {
        super(position);
    }

}
