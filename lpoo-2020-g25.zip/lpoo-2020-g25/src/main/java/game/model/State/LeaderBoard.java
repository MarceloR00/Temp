package game.model.State;

import game.model.Position;
import game.model.Score;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LeaderBoard implements State {

    private Position position;
    private Boolean isReadOnly = true;
    private Boolean isNewRecord = false;
    private StringBuffer newMember;
    private int newMemberPosition=0;
    private String newMemberScore ="";

    private List<Score> scores;

    private final int  numMaxCharacters = 16;

    public LeaderBoard(Position position) {
        this.position = position;
        newMember = new StringBuffer();
        scores = new ArrayList<>();
        readLeaderBoardScores();
    }

    public String getNewMemberScore() {
        return newMemberScore;
    }

    public int getNewMemberPosition() { return newMemberPosition; }

    public Position getPosition() {
        return position;
    }

    public Boolean getIsReadOnly() {
        return isReadOnly;
    }

    public void setIsReadOnly(Boolean readOnly) {
        this.isReadOnly = readOnly;
    }

    public void writeToNewMember(Character character){
        if(newMember.length() != numMaxCharacters){
            newMember.append(character);
        }
    }

    public void eraseLastCharFromNewMember(){
        if (newMember.length()!=0){
            newMember.deleteCharAt(newMember.length()-1);
        }
    }

    public Boolean getIsNewRecord() {
        return isNewRecord;
    }

    public void setIsNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public String getNewMember() {
        return newMember.toString();
    }

    public List<Score> getScores() {
        return scores;
    }

    private void readLeaderBoardScores(){
        try {
            FileReader scores = new FileReader(new File("./docs/scores.txt"));
            StringBuffer line = new StringBuffer();
            char character;
            int aux;
            while((aux = scores.read())!=-1){
                character = (char) aux;
                if(character == '\n'){
                    buildScore(line);
                    line =new StringBuffer();
                }else{
                    line.append(character);
                }
            }
            buildScore(line);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void buildScore(StringBuffer stringBuffer){
        int position = (int) stringBuffer.charAt(0) - 48;
        String nickname = stringBuffer.substring(1,stringBuffer.indexOf("-"));
        String score = stringBuffer.substring(stringBuffer.indexOf("-")+1);
        scores.add(new Score(position,nickname,score));
    }

    private Score getWorstScore(){
        return scores.get(scores.size()-1);
    }

    private void identifyNewMemberPosition(int score){
        for (Score score1:scores){
            if(score>Integer.parseInt(score1.getScore())){
                this.newMemberPosition = score1.getPosition();
                return;
            }
        }
    }

    public boolean newRecordBeaten(int score){
        if (score >Integer.parseInt(getWorstScore().getScore())){
            this.newMemberScore = String.valueOf(score);
            this.isReadOnly=false;
            this.isNewRecord =true;
            identifyNewMemberPosition(score);
            return true;
        }
        return false;
    }

    public void saveNewScore(){
        this.scores.add(newMemberPosition-1,new Score(newMemberPosition,newMember.toString(),newMemberScore));
        updateScoreData();
        clearNewMemberData();
    }

    private void clearNewMemberData(){
        this.newMember = new StringBuffer();
        this.newMemberScore = "";
        this.newMemberPosition = 0;
    }

    private void updateScoreData(){
        int i=1;
        this.scores.remove(this.scores.size()-1);
        for (Score score:scores){
            if (score.getPosition()!=i){
                score.setPosition(i);
            }
            i++;
        }
    }
}
