package game.model.State.ArenaElements.Enemie;

import game.model.Position;
import game.model.State.Arena;
import game.view.StrategyView;

import java.util.Random;

public class RandomMovementStrategy implements Strategy {

    Random random;
    StrategyView strategyView;

    public RandomMovementStrategy(Random random, StrategyView strategyView ) {
        this.random = random;
        this.strategyView = strategyView;
    }

    public Position getNextPosition(Position position){
        return whereTo(random.nextInt(4), position);
    }

    private Position whereTo(int direction, Position position){
        switch(direction){
            case 0:
                return position.upPosition();
            case 1:
                return  position.downPosition();
            case 2:
                return  position.leftPosition();
            case 3:
                return  position.rightPosition();
            default:
                return null;
        }
    }
}
