package game.model.State;

import game.model.Position;
import game.model.State.Menu;

public class PauseMenu extends Menu {

    public PauseMenu(Position position) {
        super(position);
    }

}
