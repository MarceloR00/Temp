package game.model.State;

import game.model.Position;
import game.model.State.State;

public class Menu implements State {
    protected int highlighted;

    protected Position position;

    public Menu(Position position){
        highlighted = 1;
        this.position = position;
    }

    public int getHighlighted() {
        return highlighted;
    }

    public void setHighlighted(int highlighted){this.highlighted = highlighted;}

    public Position getPosition() {
        return position;
    }

}
