package game.model;

import game.model.State.Arena;
import game.model.State.LeaderBoard;
import game.model.State.State;

public class Game {
    private int width;
    private int height;

    private int level;
    private boolean finish;
    private int score=0;

    private State state;
    private Arena arena;
    private LeaderBoard leaderBoard;

    public Game(int width, int height, int level, State state, Arena arena,LeaderBoard leaderBoard) {
        this.width = width;
        this.height = height;

        this.level = level;
        this.finish = false;

        this.state = state;
        this.arena = arena;
        this.leaderBoard = leaderBoard;
    }

    public int getScore() {
        return score;
    }

    public LeaderBoard getLeaderBoard() { return leaderBoard; }

    public void setLeaderBoard(LeaderBoard leaderBoard) { this.leaderBoard = leaderBoard; }

    public State getState() { return state; }

    public void setState(State state) { this.state = state; }

    public Arena getArena() { return arena; }

    public void setArena(Arena arena) { this.arena = arena; }

    public int getLevel(){ return this.level; }

    public void setLevel(int level){ this.level = level; }

    public void nextLevel(){this.level++;}

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public boolean getFinish() {
        return finish;
    }

    public void setFinish(boolean finish) {
        this.finish = finish;
    }

    public void updateScore(){ this.score++; }

    public void resetScore(){this.score=0; }
}
