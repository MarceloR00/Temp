package game.model;

import game.model.Direction.Direction;

public class ChangeDirection {
    private Position position;
    private Direction direction;

    public ChangeDirection(Position position, Direction direction) {
        this.position = position;
        this.direction = direction;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) { this.direction = direction; }
}
