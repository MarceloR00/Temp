package game;

import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.screen.TerminalScreen;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.Terminal;
import game.commands.MainMenuCommands;
import game.controller.GameController;
import game.controller.MainMenuController;
import game.model.State.Arena;
import game.model.Game;
import game.model.State.LeaderBoard;
import game.model.State.MainMenu;
import game.model.Position;
import game.view.GameView;
import game.view.MainMenuView;

import java.io.IOException;
import java.util.Random;

public class Application {

    private GameController gameController;

    public static void main(String[] args){
        try {
            new Application().start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void start() throws IOException {
        Arena arena = new ArenaCreator(new Random()).produceNewArena(100, 25, 1);
        MainMenu mainMenu = new MainMenu(new Position(arena.getWidth()/2-4,arena.getHeight()/4-1));
        LeaderBoard leaderBoard = new LeaderBoard(new Position(arena.getWidth()/2-4,arena.getHeight()/4-1));
        Game game = new Game(100, 25, 1, mainMenu, arena,leaderBoard);

        MainMenuController mainMenuController = new MainMenuController(mainMenu, new MainMenuView(mainMenu), new MainMenuCommands());

        TerminalSize terminalSize = new TerminalSize(game.getWidth(), game.getHeight() + 1);
        DefaultTerminalFactory terminalFactory = new DefaultTerminalFactory().setInitialTerminalSize(terminalSize);
        Terminal terminal = terminalFactory.createTerminal();

        GameView gameView = new GameView(new TerminalScreen(terminal));

        try {
            this.gameController = new GameController(game, mainMenuController, gameView);

            gameController.run();

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
