package game;

import game.model.*;
import game.model.State.Arena;
import game.model.State.ArenaElements.Enemie.ChaseSnakeStrategy;
import game.model.State.ArenaElements.Enemie.Enemie;
import game.model.State.ArenaElements.Snake;
import game.model.State.ArenaElements.Enemie.RandomMovementStrategy;
import game.view.ChaseSnakeView;
import game.view.RandomMovementView;

import java.util.Random;

public class ArenaCreator {
    private final Random random;

    public ArenaCreator(Random random) {
        this.random = random;
    }

    public Arena produceNewArena(int width, int height, int level) {
        Snake snake = createSnake(new Position(random.nextInt(width-10) + 5, random.nextInt(height-10) + 5));
        Arena arena = createArena(width, height,level, snake);

        createWalls(arena, level);
        createApples(arena, level);
        createRandomMovementEnemies(arena, level);
        createChaseSnakeEnemies(arena, snake.getHeadOfSnake().getPosition(), level);

        return arena;
    }

    private Snake createSnake(Position position){return new Snake(position);}

    private Arena createArena(int width, int height,int level, Snake snake){return new Arena(width, height,level, snake);}

    private void createWalls(Arena arena, int level){
        int count = level * 20;

        while(count != 0){
            arena.addTree(generateValidPosition(arena));
            count--;
        }
    }

    private void createApples(Arena arena, int level){
        int count = level * 5;

        while(count != 0){
            arena.addApple(generateValidPosition(arena));
            count--;
        }
    }

    private void createRandomMovementEnemies(Arena arena, int level){
        int count = level * 3;

        while(count != 0){
            arena.addEnemie(new Enemie(generateValidPosition(arena), arena, new RandomMovementStrategy(new Random(), new RandomMovementView())));
            count--;
        }
    }

    private void createChaseSnakeEnemies(Arena arena, Position headSnake, int level){
        int count = level * 3;

        while(count != 0){
            arena.addEnemie(new Enemie(generateValidPosition(arena), arena, new ChaseSnakeStrategy(headSnake, new ChaseSnakeView())));
            count--;
        }
    }

    private Position generateValidPosition(Arena arena){
        int x, y;

        do{
            x = random.nextInt(arena.getWidth());
            y = random.nextInt(arena.getHeight());
        } while(arena.arenaContainObjectInPosition(new Position(x, y)));

        return new Position(x, y);
    }
}
