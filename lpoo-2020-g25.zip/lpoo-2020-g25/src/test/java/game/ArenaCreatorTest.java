package game;

import game.model.State.Arena;
import org.junit.Test;
import java.util.Random;

import static org.junit.Assert.assertEquals;

public class ArenaCreatorTest {
    @Test
    public void createGameTest(){
        ArenaCreator arenaCreator = new ArenaCreator(new Random());
        assertEquals(Arena.class, arenaCreator.produceNewArena(30, 30, 1).getClass());
    }
}
