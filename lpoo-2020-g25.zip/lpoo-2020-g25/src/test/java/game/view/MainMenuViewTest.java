package game.view;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.screen.Screen;
import game.model.State.MainMenu;
import game.model.Position;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

public class MainMenuViewTest {

    MainMenu mainMenu;

    @Before
    public void setUp(){
        mainMenu = Mockito.mock(MainMenu.class);
    }

    @Test
    public void drawTest(){
        MainMenuView mainMenuView = new MainMenuView(mainMenu);

        Screen screen = Mockito.mock(Screen.class);
        TextGraphics textGraphics = Mockito.mock(TextGraphics.class);
        Position position = Mockito.mock(Position.class);

        when(mainMenu.getHighlighted()).thenReturn(1);
        when(screen.newTextGraphics()).thenReturn(textGraphics);
        when(mainMenu.getPosition()).thenReturn(position);
        when(position.getX()).thenReturn(1);
        when(position.getY()).thenReturn(1);

        mainMenuView.draw(screen);

        Mockito.verify(mainMenu, times(1)).getHighlighted();
        Mockito.verify(screen, times(1)).newTextGraphics();
        Mockito.verify(textGraphics, times(1)).setBackgroundColor(TextColor.Factory.fromString("#000000"));
        Mockito.verify(textGraphics, times(1)).setBackgroundColor(TextColor.Factory.fromString("#336699"));
        Mockito.verify(textGraphics, times(1)).setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        Mockito.verify(textGraphics, times(1)).putString(1, 3, "MAIN MENU");
        Mockito.verify(textGraphics, times(2)).putString(3, 5, "Play");
        Mockito.verify(textGraphics, times(1)).putString(3, 6, "Exit");

        when(mainMenu.getHighlighted()).thenReturn(2);

        mainMenuView.draw(screen);

        Mockito.verify(mainMenu, times(2)).getHighlighted();
        Mockito.verify(screen, times(2)).newTextGraphics();
        Mockito.verify(textGraphics, times(2)).setBackgroundColor(TextColor.Factory.fromString("#000000"));
        Mockito.verify(textGraphics, times(2)).setBackgroundColor(TextColor.Factory.fromString("#336699"));
        Mockito.verify(textGraphics, times(2)).setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        Mockito.verify(textGraphics, times(2)).putString(1, 3, "MAIN MENU");
        Mockito.verify(textGraphics, times(3)).putString(3, 5, "Play");
        Mockito.verify(textGraphics, times(3)).putString(3, 6, "Exit");
    }
}
