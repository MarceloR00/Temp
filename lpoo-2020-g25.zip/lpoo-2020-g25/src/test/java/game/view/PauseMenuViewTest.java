package game.view;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.screen.Screen;
import game.model.State.PauseMenu;
import game.model.Position;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

public class PauseMenuViewTest {

    PauseMenu pauseMenu;

    @Before
    public void setUp(){
        pauseMenu = Mockito.mock(PauseMenu.class);
    }

    @Test
    public void drawTest(){
        PauseMenuView pauseMenuView = new PauseMenuView(pauseMenu);

        Screen screen = Mockito.mock(Screen.class);
        TextGraphics textGraphics = Mockito.mock(TextGraphics.class);
        Position position = Mockito.mock(Position.class);

        when(pauseMenu.getHighlighted()).thenReturn(1);
        when(screen.newTextGraphics()).thenReturn(textGraphics);
        when(pauseMenu.getPosition()).thenReturn(position);
        when(position.getX()).thenReturn(1);
        when(position.getY()).thenReturn(1);

        pauseMenuView.draw(screen);

        Mockito.verify(pauseMenu, times(1)).getHighlighted();
        Mockito.verify(screen, times(1)).newTextGraphics();
        Mockito.verify(textGraphics, times(1)).setBackgroundColor(TextColor.Factory.fromString("#000000"));
        Mockito.verify(textGraphics, times(1)).setBackgroundColor(TextColor.Factory.fromString("#336699"));
        Mockito.verify(textGraphics, times(1)).setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        Mockito.verify(textGraphics, times(1)).putString(1, 3, "PAUSE MENU");
        Mockito.verify(textGraphics, times(2)).putString(3, 5, "Resume");
        Mockito.verify(textGraphics, times(1)).putString(3, 6, "Restart");
        Mockito.verify(textGraphics, times(1)).putString(3, 7, "MainMenu");
        Mockito.verify(textGraphics, times(1)).putString(3, 8, "Exit");

        when(pauseMenu.getHighlighted()).thenReturn(2);

        pauseMenuView.draw(screen);

        Mockito.verify(pauseMenu, times(2)).getHighlighted();
        Mockito.verify(screen, times(2)).newTextGraphics();
        Mockito.verify(textGraphics, times(2)).setBackgroundColor(TextColor.Factory.fromString("#000000"));
        Mockito.verify(textGraphics, times(2)).setBackgroundColor(TextColor.Factory.fromString("#336699"));
        Mockito.verify(textGraphics, times(2)).setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        Mockito.verify(textGraphics, times(2)).putString(1, 3, "PAUSE MENU");
        Mockito.verify(textGraphics, times(3)).putString(3, 5, "Resume");
        Mockito.verify(textGraphics, times(3)).putString(3, 6, "Restart");
        Mockito.verify(textGraphics, times(2)).putString(3, 7, "MainMenu");
        Mockito.verify(textGraphics, times(2)).putString(3, 8, "Exit");

        when(pauseMenu.getHighlighted()).thenReturn(3);

        pauseMenuView.draw(screen);

        Mockito.verify(pauseMenu, times(3)).getHighlighted();
        Mockito.verify(screen, times(3)).newTextGraphics();
        Mockito.verify(textGraphics, times(3)).setBackgroundColor(TextColor.Factory.fromString("#000000"));
        Mockito.verify(textGraphics, times(3)).setBackgroundColor(TextColor.Factory.fromString("#336699"));
        Mockito.verify(textGraphics, times(3)).setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        Mockito.verify(textGraphics, times(3)).putString(1, 3, "PAUSE MENU");
        Mockito.verify(textGraphics, times(4)).putString(3, 5, "Resume");
        Mockito.verify(textGraphics, times(4)).putString(3, 6, "Restart");
        Mockito.verify(textGraphics, times(4)).putString(3, 7, "MainMenu");
        Mockito.verify(textGraphics, times(3)).putString(3, 8, "Exit");

        when(pauseMenu.getHighlighted()).thenReturn(4);

        pauseMenuView.draw(screen);

        Mockito.verify(pauseMenu, times(4)).getHighlighted();
        Mockito.verify(screen, times(4)).newTextGraphics();
        Mockito.verify(textGraphics, times(4)).setBackgroundColor(TextColor.Factory.fromString("#000000"));
        Mockito.verify(textGraphics, times(4)).setBackgroundColor(TextColor.Factory.fromString("#336699"));
        Mockito.verify(textGraphics, times(4)).setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        Mockito.verify(textGraphics, times(4)).putString(1, 3, "PAUSE MENU");
        Mockito.verify(textGraphics, times(5)).putString(3, 5, "Resume");
        Mockito.verify(textGraphics, times(5)).putString(3, 6, "Restart");
        Mockito.verify(textGraphics, times(5)).putString(3, 7, "MainMenu");
        Mockito.verify(textGraphics, times(5)).putString(3, 8, "Exit");

    }
}
