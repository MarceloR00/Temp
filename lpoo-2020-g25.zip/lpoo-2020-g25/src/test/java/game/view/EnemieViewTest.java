package game.view;

import com.googlecode.lanterna.screen.Screen;
import game.model.State.ArenaElements.Enemie.Enemie;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

public class EnemieViewTest {
    List<Enemie> enemies = new ArrayList<>();
    Enemie enemieMock;
    Screen screen;

    @Before
    public void setUp(){
        enemieMock = Mockito.mock(Enemie.class);

        enemies.add(enemieMock);
        enemies.add(enemieMock);
        enemies.add(enemieMock);
        enemies.add(enemieMock);

        screen = Mockito.mock(Screen.class);
    }

    @Test
    public void draw(){
        EnemieView enemieView = new EnemieView(enemies);

        enemieView.draw(screen);
    }
}
