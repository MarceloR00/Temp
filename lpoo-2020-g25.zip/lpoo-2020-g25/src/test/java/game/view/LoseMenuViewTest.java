package game.view;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.screen.Screen;
import game.model.State.LoseMenu;
import game.model.Position;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

public class LoseMenuViewTest {

    LoseMenu loseMenu;

    @Before
    public void setUp(){
        loseMenu = Mockito.mock(LoseMenu.class);
    }

    @Test
    public void drawTest(){
        LoseMenuView loseMenuView = new LoseMenuView(loseMenu);

        Screen screen = Mockito.mock(Screen.class);
        TextGraphics textGraphics = Mockito.mock(TextGraphics.class);
        Position position = Mockito.mock(Position.class);

        when(loseMenu.getHighlighted()).thenReturn(1);
        when(screen.newTextGraphics()).thenReturn(textGraphics);
        when(loseMenu.getPosition()).thenReturn(position);
        when(position.getX()).thenReturn(1);
        when(position.getY()).thenReturn(1);

        loseMenuView.draw(screen);

        Mockito.verify(loseMenu, times(1)).getHighlighted();
        Mockito.verify(screen, times(1)).newTextGraphics();
        Mockito.verify(textGraphics, times(1)).setBackgroundColor(TextColor.Factory.fromString("#000000"));
        Mockito.verify(textGraphics, times(1)).setBackgroundColor(TextColor.Factory.fromString("#336699"));
        Mockito.verify(textGraphics, times(1)).setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        Mockito.verify(textGraphics, times(1)).putString(1, 3, "YOU LOSE");
        Mockito.verify(textGraphics, times(2)).putString(0, 5, "Play Again");
        Mockito.verify(textGraphics, times(1)).putString(3, 6, "Exit");

        when(loseMenu.getHighlighted()).thenReturn(2);

        loseMenuView.draw(screen);

        Mockito.verify(loseMenu, times(2)).getHighlighted();
        Mockito.verify(screen, times(2)).newTextGraphics();
        Mockito.verify(textGraphics, times(2)).setBackgroundColor(TextColor.Factory.fromString("#000000"));
        Mockito.verify(textGraphics, times(2)).setBackgroundColor(TextColor.Factory.fromString("#336699"));
        Mockito.verify(textGraphics, times(2)).setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        Mockito.verify(textGraphics, times(2)).putString(1, 3, "YOU LOSE");
        Mockito.verify(textGraphics, times(3)).putString(0, 5, "Play Again");
        Mockito.verify(textGraphics, times(3)).putString(3, 6, "Exit");
    }
}
