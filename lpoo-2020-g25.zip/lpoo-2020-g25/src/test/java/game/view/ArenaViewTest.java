package game.view;

import com.googlecode.lanterna.TerminalPosition;
import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.screen.Screen;
import game.model.State.Arena;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class ArenaViewTest {

    Arena arenaMock;
    SnakeView snakeViewMock;
    EnemieView enemieView;

    @Before
    public void setUp(){
        arenaMock = Mockito.mock(Arena.class);
        snakeViewMock = Mockito.mock(SnakeView.class);
        enemieView = Mockito.mock(EnemieView.class);
    }

    @Test
    public void drawTest(){
        ArenaView arenaView = new ArenaView(arenaMock, snakeViewMock, enemieView);

        Screen screen = Mockito.mock(Screen.class);
        TextGraphics textGraphics = Mockito.mock(TextGraphics.class);

        when(screen.newTextGraphics()).thenReturn(textGraphics);

        arenaView.draw(screen);

        Mockito.verify(screen, times(1)).newTextGraphics();
        Mockito.verify(textGraphics, times(3)).setBackgroundColor(TextColor.Factory.fromString("#228B22"));
        Mockito.verify(textGraphics, times(1)).setBackgroundColor(TextColor.Factory.fromString("#000000"));
        Mockito.verify(textGraphics, times(1)).setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        Mockito.verify(textGraphics, times(1)).setForegroundColor(TextColor.Factory.fromString("#8B4513"));
        Mockito.verify(textGraphics, times(1)).setForegroundColor(TextColor.Factory.fromString("#FF0000"));
        Mockito.verify(textGraphics, atLeast(1)).putString(any(Integer.class), any(Integer.class), any(String.class));
        Mockito.verify(textGraphics, times(1)).fillRectangle(any(TerminalPosition.class), any(TerminalSize.class), any(Character.class));
        Mockito.verify(snakeViewMock, times(1)).draw(screen);
    }

}
