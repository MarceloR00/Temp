package game.view;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.screen.Screen;
import game.model.State.LevelTransaction;
import game.model.Position;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

public class LevelTransactionViewTest {

    LevelTransaction levelTransaction;

    @Before
    public void setUp(){
        levelTransaction = Mockito.mock(LevelTransaction.class);
    }

    @Test
    public void drawTest(){
        LevelTransactionView levelTransactionView = new LevelTransactionView(levelTransaction);

        Screen screen = Mockito.mock(Screen.class);
        TextGraphics textGraphics = Mockito.mock(TextGraphics.class);
        Position position = Mockito.mock(Position.class);

        when(levelTransaction.getLevel()).thenReturn(1);
        when(screen.newTextGraphics()).thenReturn(textGraphics);
        when(levelTransaction.getPosition()).thenReturn(position);
        when(position.getX()).thenReturn(1);
        when(position.getY()).thenReturn(1);

        levelTransactionView.draw(screen);

        Mockito.verify(levelTransaction, times(1)).getLevel();
        Mockito.verify(screen, times(1)).newTextGraphics();
        Mockito.verify(textGraphics, times(1)).setBackgroundColor(TextColor.Factory.fromString("#000000"));
        Mockito.verify(textGraphics, times(1)).setForegroundColor(TextColor.Factory.fromString("#FFFFFF"));
        Mockito.verify(textGraphics, times(1)).putString(1, 4, "LEVEL 1");
        Mockito.verify(textGraphics, times(1)).putString(-13, 6, "Walls: 20 / Apples: 5 / Enemies: 5");

        when(levelTransaction.getLevel()).thenReturn(2);

        levelTransactionView.draw(screen);

        Mockito.verify(levelTransaction, times(2)).getLevel();
        Mockito.verify(screen, times(2)).newTextGraphics();
        Mockito.verify(textGraphics, times(2)).setBackgroundColor(TextColor.Factory.fromString("#000000"));
        Mockito.verify(textGraphics, times(1)).putString(-2, 2, "LEVEL PASSED");
        Mockito.verify(textGraphics, times(1)).putString(-2, 4, "NEXT LEVEL 2");
        Mockito.verify(textGraphics, times(1)).putString(-13, 6, "Walls: 40 / Apples: 10 / Enemies: 10");
    }
}
