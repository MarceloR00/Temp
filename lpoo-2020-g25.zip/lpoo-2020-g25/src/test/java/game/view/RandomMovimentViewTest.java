package game.view;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.screen.Screen;
import game.model.Position;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

public class RandomMovimentViewTest {

    Position positionMock;
    Screen screen;
    TextGraphics textGraphics;

    @Before
    public void setUp(){
        positionMock = Mockito.mock(Position.class);
        screen = Mockito.mock(Screen.class);
        textGraphics = Mockito.mock(TextGraphics.class);

        when(positionMock.getX()).thenReturn(2);
        when(positionMock.getY()).thenReturn(4);
        when(screen.newTextGraphics()).thenReturn(textGraphics);
    }

    @Test
    public void draw(){
        RandomMovementView randomMovimentView = new RandomMovementView(positionMock);

        randomMovimentView.draw(screen);

        Mockito.verify(screen, times(1)).newTextGraphics();
        Mockito.verify(textGraphics, times(1)).setBackgroundColor(TextColor.Factory.fromString("#228B22"));
        Mockito.verify(textGraphics, times(1)).setForegroundColor(TextColor.Factory.fromString("#0000FF"));
        Mockito.verify(textGraphics, times(1)).putString(2, 4, "R");
    }
}
