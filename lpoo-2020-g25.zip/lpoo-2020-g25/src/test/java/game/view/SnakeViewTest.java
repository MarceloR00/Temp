package game.view;

import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.screen.Screen;
import game.model.BodyPart;
import game.model.Position;
import game.model.State.ArenaElements.Snake;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

public class SnakeViewTest {

    Snake snake;

    @Before
    public void setUp(){
        snake = Mockito.mock(Snake.class);
    }

    @Test
    public void drawTest(){
        SnakeView snakeView = new SnakeView(snake);

        Screen screen = Mockito.mock(Screen.class);
        TextGraphics textGraphics = Mockito.mock(TextGraphics.class);
        Position position = Mockito.mock(Position.class);
        BodyPart bodyPart = Mockito.mock(BodyPart.class);

        List<BodyPart> body = new ArrayList<>();
        body.add(bodyPart);
        body.add(bodyPart);
        body.add(bodyPart);
        body.add(bodyPart);

        when(snake.getBody()).thenReturn(body);
        when(screen.newTextGraphics()).thenReturn(textGraphics);
        when(bodyPart.getPosition()).thenReturn(position);
        when(position.getX()).thenReturn(1);
        when(position.getY()).thenReturn(1);

        snakeView.draw(screen);

        Mockito.verify(snake, times(1)).getBody();
        Mockito.verify(screen, times(1)).newTextGraphics();
        Mockito.verify(textGraphics, times(1)).setBackgroundColor(TextColor.Factory.fromString("#228B22"));
        Mockito.verify(textGraphics, times(1)).setForegroundColor(TextColor.Factory.fromString("#FFFF00"));
        Mockito.verify(textGraphics, times(1)).putString(1, 1, "o");
        Mockito.verify(textGraphics, times(3)).putString(1, 1, "+");

    }
}
