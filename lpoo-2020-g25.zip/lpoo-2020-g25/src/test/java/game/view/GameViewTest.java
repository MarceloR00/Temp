package game.view;

import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.screen.TerminalScreen;
import game.controller.GameController;
import game.controller.StateController;
import game.model.Game;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import javax.swing.*;
import javax.swing.plaf.nimbus.State;
import java.io.IOException;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

public class GameViewTest {

    Game gameMock;
    GameController gameControllerMock;
    TerminalScreen terminalScreen;

    @Before
    public void setUp(){
        gameMock = Mockito.mock(Game.class);
        gameControllerMock = Mockito.mock(GameController.class);
        terminalScreen = Mockito.mock(TerminalScreen.class);
    }

    @Test
    public void getNextCommandTest(){
        try {
            GameView gameView = new GameView(terminalScreen);

            KeyStroke keyStrokeMock = Mockito.mock(KeyStroke.class);

            gameView.getNextCommand(gameControllerMock);

            when(terminalScreen.pollInput()).thenReturn(null);

            Mockito.verify(gameControllerMock, times(1)).none();

            when(terminalScreen.pollInput()).thenReturn(keyStrokeMock);
            when(keyStrokeMock.getKeyType()).thenReturn(KeyType.EOF);

            gameView.getNextCommand(gameControllerMock);

            Mockito.verify(gameControllerMock, times(1)).exit();

            when(terminalScreen.pollInput()).thenReturn(keyStrokeMock);
            when(keyStrokeMock.getKeyType()).thenReturn(KeyType.Escape);

            gameView.getNextCommand(gameControllerMock);

            Mockito.verify(gameControllerMock, times(1)).esc();

            when(terminalScreen.pollInput()).thenReturn(keyStrokeMock);
            when(keyStrokeMock.getKeyType()).thenReturn(KeyType.Enter);

            gameView.getNextCommand(gameControllerMock);

            Mockito.verify(gameControllerMock, times(1)).enter();

            when(terminalScreen.pollInput()).thenReturn(keyStrokeMock);
            when(keyStrokeMock.getKeyType()).thenReturn(KeyType.ArrowDown);

            gameView.getNextCommand(gameControllerMock);

            Mockito.verify(gameControllerMock, times(1)).arrowDown();

            when(terminalScreen.pollInput()).thenReturn(keyStrokeMock);
            when(keyStrokeMock.getKeyType()).thenReturn(KeyType.ArrowUp);

            gameView.getNextCommand(gameControllerMock);

            Mockito.verify(gameControllerMock, times(1)).arrowUp();

            when(terminalScreen.pollInput()).thenReturn(keyStrokeMock);
            when(keyStrokeMock.getKeyType()).thenReturn(KeyType.ArrowLeft);

            gameView.getNextCommand(gameControllerMock);

            Mockito.verify(gameControllerMock, times(1)).arrowLeft();

            when(terminalScreen.pollInput()).thenReturn(keyStrokeMock);
            when(keyStrokeMock.getKeyType()).thenReturn(KeyType.ArrowRight);

            gameView.getNextCommand(gameControllerMock);

            Mockito.verify(gameControllerMock, times(1)).arrowRight();

            when(terminalScreen.pollInput()).thenReturn(keyStrokeMock);
            when(keyStrokeMock.getKeyType()).thenReturn(KeyType.Backspace);

            gameView.getNextCommand(gameControllerMock);

            Mockito.verify(gameControllerMock, times(2)).none();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void drawTest(){
        try {
            GameView gameView = new GameView(terminalScreen);

            StateController stateControllerMock = Mockito.mock(StateController.class);

            gameView.draw(stateControllerMock);

            Mockito.verify(terminalScreen, times(1)).clear();
            Mockito.verify(stateControllerMock, times(1)).draw(terminalScreen);
            Mockito.verify(terminalScreen, times(1)).refresh();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void endGameTest(){
        try {
            GameView gameView = new GameView(terminalScreen);

            gameView.endGame();

            Mockito.verify(terminalScreen, times(1)).close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
