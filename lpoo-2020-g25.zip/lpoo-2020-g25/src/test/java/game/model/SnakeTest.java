package game.model;

import game.model.Direction.Direction;
import game.model.State.ArenaElements.Snake;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import java.util.List;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

public class SnakeTest {

    Position positionMock;
    Snake snake;

    @Before
    public void setUp(){
        positionMock = Mockito.mock(Position.class);

        when(positionMock.getX()).thenReturn(5);
        when(positionMock.getY()).thenReturn(10);

        snake = new Snake(positionMock);
    }

    @Test
    public void getSnakeSizeTest(){
        assertEquals(1, snake.getSnakeSize());
    }

    @Test
    public void getBodyTest(){
        List<BodyPart> list1 = snake.getBody();

        assertEquals(1, list1.size());
        assertEquals(positionMock, list1.get(0).getPosition());
    }

    @Test
    public void getInitialPositionTest(){
        assertEquals(positionMock, snake.getInitialPosition());
    }

    @Test
    public void  upPositionTest(){
        Position positionMock2 = Mockito.mock(Position.class);

        when(positionMock.upPosition()).thenReturn(positionMock2);

        assertEquals(positionMock2, snake.upPosition());
    }

    @Test
    public void  downPositionTest(){
        Position positionMock2 = Mockito.mock(Position.class);

        when(positionMock.downPosition()).thenReturn(positionMock2);

        assertEquals(positionMock2, snake.downPosition());
    }

    @Test
    public void rightPositionTest(){
        Position positionMock2 = Mockito.mock(Position.class);

        when(positionMock.rightPosition()).thenReturn(positionMock2);

        assertEquals(positionMock2, snake.rightPosition());
    }


    @Test
    public void  leftPositionTest(){
        Position positionMock2 = Mockito.mock(Position.class);

        when(positionMock.leftPosition()).thenReturn(positionMock2);

        assertEquals(positionMock2, snake.leftPosition());
    }

    @Test
    public void getDirectionTest(){
        Direction directionMock = Mockito.mock(Direction.class);
        when(directionMock.getDirection()).thenReturn(Direction.Directions.RIGHT);

        snake.setInitialDirection(directionMock);
        assertEquals(Direction.Directions.RIGHT, snake.getDirection());
    }

    @Test
    public void getHeadOfSnakeTest(){
        assertEquals(positionMock, snake.getHeadOfSnake().getPosition());
    }

    @Test
    public void getTailOfSnakeTest(){
        assertEquals(positionMock, snake.getTailOfSnake().getPosition());
    }

    @Test
    public void setInitialDirectionTest(){
        snake.setInitialDirection(new Direction(Direction.Directions.RIGHT));

        assertEquals(new Direction(Direction.Directions.RIGHT).getDirection(), snake.getDirection());

        snake.setInitialDirection(new Direction(Direction.Directions.LEFT));

        assertEquals(new Direction(Direction.Directions.LEFT).getDirection(), snake.getDirection());

        snake.setInitialDirection(new Direction(Direction.Directions.UP));

        assertEquals(new Direction(Direction.Directions.UP).getDirection(), snake.getDirection());

        snake.setInitialDirection(new Direction(Direction.Directions.DOWN));

        assertEquals(new Direction(Direction.Directions.DOWN).getDirection(), snake.getDirection());
    }

    @Test
    public void colisionWithEnemieTest(){
        Position positionMock2 = Mockito.mock(Position.class);

        when(positionMock2.getX()).thenReturn(4);
        when(positionMock2.getY()).thenReturn(10);

        assertTrue(snake.collisionWithEnemieAt(positionMock));

        assertFalse(snake.collisionWithEnemieAt(positionMock2));

    }

    @Test
    public void getNextPositionTest(){
        snake.setInitialDirection(new Direction(Direction.Directions.UP));

        assertEquals(snake.upPosition(), snake.getNextPosition());

        snake.setInitialDirection(new Direction(Direction.Directions.DOWN));

        assertEquals(snake.downPosition(), snake.getNextPosition());

        snake.setInitialDirection(new Direction(Direction.Directions.LEFT));

        assertEquals(snake.leftPosition(), snake.getNextPosition());
    }
}
