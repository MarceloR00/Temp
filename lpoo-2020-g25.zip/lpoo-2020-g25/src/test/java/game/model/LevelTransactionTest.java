package game.model;

import game.model.State.LevelTransaction;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;

public class LevelTransactionTest {

    @Test
    public void getLevelTest(){
        Position positionMock = Mockito.mock(Position.class);

        LevelTransaction levelTransaction = new LevelTransaction(positionMock, 1);

        assertEquals(1, levelTransaction.getLevel());
    }


}
