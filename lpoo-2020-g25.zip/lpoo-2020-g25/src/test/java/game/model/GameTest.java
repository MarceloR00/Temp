package game.model;

import game.model.State.Arena;
import game.model.State.State;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.*;

public class GameTest {

    Game game;

    @Before
    public void setUp(){
        State state = Mockito.mock(State.class);
        Arena arena = Mockito.mock(Arena.class);
        game = new Game(20, 30, 1, state, arena);
    }

    @Test
    public void getWidthTest(){
        assertEquals(20, game.getWidth());
    }

    @Test
    public void setWidthTest(){
        game.setWidth(3);
        assertEquals(3, game.getWidth());
    }

    @Test
    public void getHeightTest(){
        assertEquals(30, game.getHeight());
    }

    @Test
    public void setHeightTest(){
        game.setHeight(3);
        assertEquals(3, game.getHeight());
    }

    @Test
    public void getFinishTest() {
        assertFalse(game.getFinish());
    }

    @Test
    public void getLevelTest() {
        assertEquals(1, game.getLevel());
    }

    @Test
    public void setLevelTest() {
        game.setLevel(2);
        assertEquals(2, game.getLevel());
    }

    @Test
    public void setFinishTest() {
        game.setFinish(true);
        assertTrue(game.getFinish());
    }

    @Test
    public void nextLevelTest(){
        game.setLevel(1);
        assertEquals(1,game.getLevel());
        game.nextLevel();
        assertEquals(2,game.getLevel());
    }

 }
