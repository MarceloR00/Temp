package game.model;

import game.model.Direction.Direction;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class BodyPartTest {

    Direction directionMock;
    Position positionMock;
    BodyPart bodyPart;
    List<ChangeDirection> changeDirections;
    ChangeDirection changeDirectionMock;

    @Before
    public void setup(){
        directionMock = mock(Direction.class);
        when(directionMock.getDirection()).thenReturn(Direction.Directions.LEFT);

        changeDirections = new ArrayList<>();

        positionMock = Mockito.mock(Position.class);

        changeDirectionMock = mock(ChangeDirection.class);
        when(changeDirectionMock.getDirection()).thenReturn(directionMock);
        when(changeDirectionMock.getPosition()).thenReturn(positionMock);
    }

    @Test
    public void getPositionTest(){
        Position tmp = new Position(-1,0);
        bodyPart = new BodyPart(tmp);
        assertEquals(tmp,bodyPart.getPosition());
    }

    @Test
    public void setPositionTest(){
        Position tmp = new Position(-2,3);
        bodyPart = new BodyPart(positionMock);
        bodyPart.setPosition(tmp);
        assertEquals(tmp,bodyPart.getPosition());
    }

    @Test
    public void getDirectionTest(){
        bodyPart = new BodyPart(positionMock,directionMock);
        assertEquals(Direction.Directions.LEFT,bodyPart.getDirection());
    }

    @Test
    public void setDirectionTest(){
        bodyPart = new BodyPart(positionMock);
        bodyPart.setDirection(directionMock);
        assertEquals(Direction.Directions.LEFT,bodyPart.getDirection());
    }

    @Test
    public void getChangeDirectionTest(){
        bodyPart = new BodyPart(positionMock);
        assertEquals(0,bodyPart.getChangeDirections().size());

    }

    @Test
    public void getChangeDirectionTest2(){
        bodyPart = new BodyPart(positionMock);
        assertEquals(0,bodyPart.getChangeDirections().size());

        changeDirections.add(changeDirectionMock);
        bodyPart.setChangeDirections(changeDirections);

        assertNotEquals(0,bodyPart.getChangeDirections().size());
    }

    @Test
    public void getChangeDirectionTest3(){
        bodyPart = new BodyPart(positionMock);
        assertTrue(bodyPart.getChangeDirections().isEmpty());

        changeDirections.add(changeDirectionMock);
        changeDirections.add(changeDirectionMock);
        bodyPart.setChangeDirections(changeDirections);

        assertEquals(2,bodyPart.getChangeDirections().size());
    }


    @Test
    public void setChangeDirectionsTest(){
        bodyPart = new BodyPart(positionMock);

        changeDirections.add(changeDirectionMock);
        bodyPart.setChangeDirections(changeDirections);

        assertEquals(positionMock,changeDirections.get(0).getPosition());
        assertEquals(directionMock,changeDirections.get(0).getDirection());
    }

    @Test
    public void goNextPositionTest(){
        bodyPart = new BodyPart(positionMock,directionMock);
        assertEquals(Direction.Directions.LEFT,bodyPart.getDirection());

        bodyPart.goNextPosition();

        Mockito.verify(positionMock,times(1)).setX(anyInt());

        when(directionMock.getDirection()).thenReturn(Direction.Directions.RIGHT);
        bodyPart.setDirection(directionMock);
        assertEquals(Direction.Directions.RIGHT,bodyPart.getDirection());


        bodyPart.goNextPosition();

        Mockito.verify(positionMock,times(2)).setX(anyInt());

        when(directionMock.getDirection()).thenReturn(Direction.Directions.UP);
        bodyPart.setDirection(directionMock);
        assertEquals(Direction.Directions.UP,bodyPart.getDirection());

        bodyPart.goNextPosition();

        Mockito.verify(positionMock,times(1)).setY(anyInt());

        when(directionMock.getDirection()).thenReturn(Direction.Directions.DOWN);
        bodyPart.setDirection(directionMock);
        assertEquals(Direction.Directions.DOWN,bodyPart.getDirection());

        bodyPart.goNextPosition();

        Mockito.verify(positionMock,times(2)).setY(anyInt());
    }

    @Test
    public void addChangeDirectionsTest(){
        bodyPart = new BodyPart(positionMock);
        assertEquals(0,bodyPart.getChangeDirections().size());

        bodyPart.addChangeDirections(positionMock,directionMock);
        assertNotEquals(0,bodyPart.getChangeDirections().size());
    }

    @Test
    public void addChangeDirectionsTest2(){
        bodyPart = new BodyPart(positionMock);
        assertEquals(0,bodyPart.getChangeDirections().size());

        Position tmp = new Position(25,28);
        bodyPart.addChangeDirections(tmp,directionMock);
        bodyPart.addChangeDirections(positionMock,directionMock);

        assertFalse(bodyPart.getChangeDirections().isEmpty());
        assertEquals(2,bodyPart.getChangeDirections().size());
    }

    @Test
    public void predictNextPositionTest(){
        bodyPart = new BodyPart(positionMock,directionMock);

        when(positionMock.leftPosition()).thenReturn(new Position(3,2));
        when(positionMock.rightPosition()).thenReturn(new Position(3,2));
        when(positionMock.upPosition()).thenReturn(new Position(3,2));
        when(positionMock.rightPosition()).thenReturn(new Position(3,2));

        bodyPart.predictNextPosition();

        when(directionMock.getDirection()).thenReturn(Direction.Directions.RIGHT);
        bodyPart.predictNextPosition();

        when(directionMock.getDirection()).thenReturn(Direction.Directions.UP);
        bodyPart.predictNextPosition();

        when(directionMock.getDirection()).thenReturn(Direction.Directions.DOWN);
        bodyPart.predictNextPosition();

        Mockito.verify(positionMock,times(1)).leftPosition();
        Mockito.verify(positionMock,times(1)).upPosition();
        Mockito.verify(positionMock,times(1)).downPosition();
        Mockito.verify(positionMock,times(1)).rightPosition();

    }

}
