package game.model;

import game.model.Direction.Direction;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class DirectionTest {

    private Direction direction;

    @Before
    public void setup(){
        direction = new Direction(Direction.Directions.UP);
    }

    @Test
    public void getDirectionTest(){
        Direction direction = new Direction(Direction.Directions.UP);
        assertEquals(direction.getDirection(),this.direction.getDirection());
    }

    @Test
    public void getDirectionTest2(){
        Direction direction = new Direction(Direction.Directions.DOWN);
        assertNotEquals(direction.getDirection(),this.direction.getDirection());
    }

    @Test
    public void setDirectionTest(){
        Direction direction = new Direction(Direction.Directions.LEFT);
        this.direction.setDirection(direction.getDirection());
        assertEquals(direction.getDirection(),this.direction.getDirection());
    }

    @Test
    public void setDirectionTest2(){
        Direction direction = new Direction(Direction.Directions.UP);
        this.direction.setDirection(direction.getDirection());
        assertEquals(direction.getDirection(),this.direction.getDirection());
    }

    @Test
    public void setDirectionTest3(){
        Direction direction = new Direction(Direction.Directions.DOWN);
        this.direction.setDirection(direction.getDirection());
        assertEquals(direction.getDirection(),this.direction.getDirection());
    }


}
