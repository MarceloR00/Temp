package game.model;

import game.model.Direction.Direction;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;


public class ChangeDirectionTest {

    private ChangeDirection changeDirection;

    @Before
    public void setup(){
       Position position = new Position(5,5);
       Direction direction = new Direction(Direction.Directions.LEFT);
       changeDirection = new ChangeDirection(position,direction);
    }

    @Test
    public void getPositionTest(){
        Position position = new Position(5,5);
        assertEquals(position,changeDirection.getPosition());
    }

    @Test
    public void getPositionTest2(){
        Position position = new Position(-5,5);
        assertNotEquals(position,changeDirection.getPosition());
    }

    @Test
    public void getPositionTest3(){
        Position position = new Position(-10,0);
        assertNotEquals(position,changeDirection.getPosition());
    }

    @Test
    public void setPositionTest(){
        Position position = new Position(15,15);
        changeDirection.setPosition(position);
        assertEquals(position,changeDirection.getPosition());

    }

    @Test
    public void setPositionTest2(){
        Position position = new Position(-12,15);
        changeDirection.setPosition(position);
        assertEquals(position,changeDirection.getPosition());

    }

    @Test
    public void setPositionTest3(){
        Position position = new Position(0,-1);
        changeDirection.setPosition(position);
        assertEquals(position,changeDirection.getPosition());

    }

    @Test
    public void getDirectionTest(){
        Direction direction = new Direction(Direction.Directions.LEFT);
        assertEquals(direction.getDirection(),changeDirection.getDirection().getDirection());
    }

    @Test
    public void getDirectionTest2(){
        Direction direction = new Direction(Direction.Directions.DOWN);
        assertNotEquals(direction.getDirection(),changeDirection.getDirection().getDirection());
    }

    @Test
    public void setDirectionTest(){
        Direction direction = new Direction(Direction.Directions.DOWN);
        changeDirection.setDirection(direction);
        assertEquals(direction,changeDirection.getDirection());
    }

    @Test
    public void setDirectionTest2(){
        Direction direction = new Direction(Direction.Directions.RIGHT);
        changeDirection.setDirection(direction);
        assertEquals(direction,changeDirection.getDirection());
    }

    @Test
    public void setDirectionTest3(){
        Direction direction = new Direction(Direction.Directions.UP);
        changeDirection.setDirection(direction);
        assertEquals(direction,changeDirection.getDirection());
    }

}
