package game.model;

import game.model.State.Arena;
import game.model.State.ArenaElements.Snake;
import game.model.State.ArenaElements.Enemie.Enemie;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class ArenaTest {

    Arena arena;
    Enemie enemieMock1;

    Position positionTreeMock1;
    Position positionAppleMock1;
    Position positionEnemieMock1;

    @Before
    public void setUp(){
        Snake snake = Mockito.mock(Snake.class);

        arena = new Arena(100, 50,1, snake);

        positionTreeMock1 = Mockito.mock(Position.class);
        when(positionTreeMock1.getX()).thenReturn(5);
        when(positionTreeMock1.getY()).thenReturn(5);
        Position positionTreeMock2 = Mockito.mock(Position.class);
        when(positionTreeMock2.getX()).thenReturn(5);
        when(positionTreeMock2.getY()).thenReturn(6);
        Position positionTreeMock3 = Mockito.mock(Position.class);
        when(positionTreeMock3.getX()).thenReturn(5);
        when(positionTreeMock3.getY()).thenReturn(7);
        Position positionTreeMock4 = Mockito.mock(Position.class);
        when(positionTreeMock4.getX()).thenReturn(5);
        when(positionTreeMock4.getY()).thenReturn(8);

        arena.addTree(positionTreeMock1);
        arena.addTree(positionTreeMock2);
        arena.addTree(positionTreeMock3);
        arena.addTree(positionTreeMock4);

        positionAppleMock1 = Mockito.mock(Position.class);
        when(positionAppleMock1.getX()).thenReturn(6);
        when(positionAppleMock1.getY()).thenReturn(5);
        Position positionAppleMock2 = Mockito.mock(Position.class);
        when(positionAppleMock2.getX()).thenReturn(6);
        when(positionAppleMock2.getY()).thenReturn(6);
        Position positionAppleMock3 = Mockito.mock(Position.class);
        when(positionAppleMock3.getX()).thenReturn(6);
        when(positionAppleMock3.getY()).thenReturn(7);
        Position positionAppleMock4 = Mockito.mock(Position.class);
        when(positionAppleMock4.getX()).thenReturn(6);
        when(positionAppleMock4.getY()).thenReturn(8);

        arena.addApple(positionAppleMock1);
        arena.addApple(positionAppleMock2);
        arena.addApple(positionAppleMock3);
        arena.addApple(positionAppleMock4);

        enemieMock1 = Mockito.mock(Enemie.class);
        positionEnemieMock1 = Mockito.mock(Position.class);
        when(enemieMock1.getPosition()).thenReturn(positionEnemieMock1);
        when(positionEnemieMock1.getX()).thenReturn(7);
        when(positionEnemieMock1.getY()).thenReturn(5);
        Enemie enemieMock2 = Mockito.mock(Enemie.class);
        Position positionEnemieMock2 = Mockito.mock(Position.class);
        when(enemieMock2.getPosition()).thenReturn(positionEnemieMock2);
        when(positionEnemieMock2.getX()).thenReturn(7);
        when(positionEnemieMock2.getY()).thenReturn(6);
        Enemie enemieMock3 = Mockito.mock(Enemie.class);
        Position positionEnemieMock3 = Mockito.mock(Position.class);
        when(enemieMock3.getPosition()).thenReturn(positionEnemieMock3);
        when(positionEnemieMock3.getX()).thenReturn(7);
        when(positionEnemieMock3.getY()).thenReturn(7);
        Enemie enemieMock4 = Mockito.mock(Enemie.class);
        Position positionEnemieMock4 = Mockito.mock(Position.class);
        when(enemieMock4.getPosition()).thenReturn(positionEnemieMock4);
        when(positionEnemieMock4.getX()).thenReturn(7);
        when(positionEnemieMock4.getY()).thenReturn(8);

        arena.addEnemie(enemieMock1);
        arena.addEnemie(enemieMock2);
        arena.addEnemie(enemieMock3);
        arena.addEnemie(enemieMock4);

    }
    @Test
    public void getLevelTest(){
        assertEquals(1,arena.getLevel());
    }

    @Test
    public void isMovingObjectsTest(){
        assertFalse(arena.isMovingObjects());
    }

    @Test
    public void setMovingObjectsTest(){
        arena.setMovingObjects(true);

        assertTrue(arena.isMovingObjects());
    }

    @Test
    public void getWidthTest(){
        assertEquals(100, arena.getWidth());
    }

    @Test
    public void setWidthTest(){
        arena.setWidth(33);

        assertEquals(33, arena.getWidth());
    }

    @Test
    public void getHeightTest(){
        assertEquals(50, arena.getHeight());
    }

    @Test
    public void setHeightTest(){
        arena.setHeight(33);

        assertEquals(33, arena.getHeight());
    }

    @Test
    public void getWallsTest(){
        assertEquals(4, arena.getTrees().size());
        assertEquals(5, arena.getTrees().get(0).getX());
        assertEquals(5, arena.getTrees().get(0).getY());
        assertEquals(5, arena.getTrees().get(1).getX());
        assertEquals(6, arena.getTrees().get(1).getY());
        assertEquals(5, arena.getTrees().get(2).getX());
        assertEquals(7, arena.getTrees().get(2).getY());
        assertEquals(5, arena.getTrees().get(3).getX());
        assertEquals(8, arena.getTrees().get(3).getY());

    }

    @Test
    public void getApplesTest(){
        assertEquals(4, arena.getApples().size());
        assertEquals(6, arena.getApples().get(0).getX());
        assertEquals(5, arena.getApples().get(0).getY());
        assertEquals(6, arena.getApples().get(1).getX());
        assertEquals(6, arena.getApples().get(1).getY());
        assertEquals(6, arena.getApples().get(2).getX());
        assertEquals(7, arena.getApples().get(2).getY());
        assertEquals(6, arena.getApples().get(3).getX());
        assertEquals(8, arena.getApples().get(3).getY());
    }

    @Test
    public void getEnemiesTest(){
        assertEquals(4, arena.getEnemies().size());
        assertEquals(7, arena.getEnemies().get(0).getPosition().getX());
        assertEquals(5, arena.getEnemies().get(0).getPosition().getY());
        assertEquals(7, arena.getEnemies().get(1).getPosition().getX());
        assertEquals(6, arena.getEnemies().get(1).getPosition().getY());
        assertEquals(7, arena.getEnemies().get(2).getPosition().getX());
        assertEquals(7, arena.getEnemies().get(2).getPosition().getY());
        assertEquals(7, arena.getEnemies().get(3).getPosition().getX());
        assertEquals(8, arena.getEnemies().get(3).getPosition().getY());
    }

    @Test
    public void addWallTest(){
        Position positionMock = Mockito.mock(Position.class);

        assertEquals(4, arena.getTrees().size());

        arena.addTree(positionMock);;

        assertEquals(5, arena.getTrees().size());
        assertEquals(positionMock, arena.getTrees().get(4));

        arena.addTree(positionMock);

        assertEquals(6, arena.getTrees().size());
        assertEquals(positionMock, arena.getTrees().get(5));
    }

    @Test
    public void addAppleTest(){
        Position positionMock = Mockito.mock(Position.class);

        assertEquals(4, arena.getApples().size());

        arena.addApple(positionMock);

        assertEquals(5, arena.getApples().size());
        assertEquals(positionMock, arena.getApples().get(4));

        arena.addApple(positionMock);

        assertEquals(6, arena.getApples().size());
        assertEquals(positionMock, arena.getApples().get(5));
    }
    @Test
    public void addEnemieTest(){
        Enemie enemie = Mockito.mock(Enemie.class);

        assertEquals(4, arena.getEnemies().size());

        arena.addEnemie(enemie);

        assertEquals(5, arena.getEnemies().size());
        assertEquals(enemie, arena.getEnemies().get(4));

        arena.addEnemie(enemie);

        assertEquals(6, arena.getEnemies().size());
        assertEquals(enemie, arena.getEnemies().get(5));
    }

    @Test
    public void canMoveToTest(){
        Position positionMock = Mockito.mock(Position.class);

        when(positionMock.getX()).thenReturn(99);
        when(positionMock.getY()).thenReturn(49);

        assertTrue(arena.canMoveTo(positionMock));

        when(positionMock.getX()).thenReturn(-3);
        when(positionMock.getY()).thenReturn(-3);

        assertFalse(arena.canMoveTo(positionMock));

        when(positionMock.getX()).thenReturn(-3);
        when(positionMock.getY()).thenReturn(5);

        assertFalse(arena.canMoveTo(positionMock));

        when(positionMock.getX()).thenReturn(5);
        when(positionMock.getY()).thenReturn(-3);

        assertFalse(arena.canMoveTo(positionMock));

        when(positionMock.getX()).thenReturn(5);
        when(positionMock.getY()).thenReturn(53);

        assertFalse(arena.canMoveTo(positionMock));

        when(positionMock.getX()).thenReturn(101);
        when(positionMock.getY()).thenReturn(5);

        assertFalse(arena.canMoveTo(positionMock));

        when(positionMock.getX()).thenReturn(101);
        when(positionMock.getY()).thenReturn(5);

        assertFalse(arena.canMoveTo(positionMock));
    }

    @Test
    public void arenaContainObjectInPosition(){
        assertTrue(arena.arenaContainObjectInPosition(positionTreeMock1));

        assertTrue(arena.arenaContainObjectInPosition(positionAppleMock1));

        assertTrue(arena.arenaContainObjectInPosition(positionEnemieMock1));
    }

    @Test
    public void TreeInThatPositionTest(){
        Position positionMock = Mockito.mock(Position.class);

        when(positionMock.getX()).thenReturn(20);
        when(positionMock.getY()).thenReturn(20);

        assertFalse(arena.TreeInThatPosition(positionMock));

        assertTrue(arena.TreeInThatPosition(positionTreeMock1));
    }

    @Test
    public void AppleInThatPositionTest(){
        Position positionMock = Mockito.mock(Position.class);

        when(positionMock.getX()).thenReturn(20);
        when(positionMock.getY()).thenReturn(20);

        assertFalse(arena.AppleInThatPosition(positionMock));

        assertTrue(arena.AppleInThatPosition(positionAppleMock1));
    }

    @Test
    public void EnemieInThatPositionTest(){
        Position positionMock = Mockito.mock(Position.class);

        when(positionMock.getX()).thenReturn(20);
        when(positionMock.getY()).thenReturn(20);

        assertFalse(arena.EnemieInThatPosition(positionMock));

        assertTrue(arena.EnemieInThatPosition(positionEnemieMock1));
    }

}
