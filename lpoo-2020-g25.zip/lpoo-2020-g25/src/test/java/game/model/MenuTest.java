package game.model;

import game.model.State.Menu;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

public class MenuTest {

    Menu menu;
    Position positionMock;

    @Before
    public void setUp(){
        positionMock = Mockito.mock(Position.class);
        menu = new Menu(positionMock);

        when(positionMock.getX()).thenReturn(100);
        when(positionMock.getY()).thenReturn(50);
    }

    @Test
    public void getHighlightedTest(){

        assertEquals(1, menu.getHighlighted());
    }

    @Test
    public void setHighlightedTest(){

        menu.setHighlighted(4);

        assertEquals(4, menu.getHighlighted());
    }

    @Test
    public void getPositionTest(){
        assertEquals(100, menu.getPosition().getX());
        assertEquals(50, menu.getPosition().getY());
    }
}
