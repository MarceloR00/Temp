package game.controller;

import game.model.*;
import game.model.State.PauseMenu;
import game.view.PauseMenuView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

public class PauseMenuControllerTest {

    PauseMenu pauseMenuMock;
    PauseMenuController pauseMenuController;
    PauseMenuView pauseMenuViewMock;
    GameController gameControllerMock;

    @Before
    public void setUp(){
        this.pauseMenuMock = Mockito.mock(PauseMenu.class);
        this.pauseMenuViewMock = Mockito.mock(PauseMenuView.class);
        this.pauseMenuController = new PauseMenuController(pauseMenuMock,pauseMenuViewMock);
        gameControllerMock = Mockito.mock(GameController.class);
    }

    @Test
    public void getMainMenuTest(){
        assertEquals(pauseMenuMock, pauseMenuController.getPauseMenu());
    }

    @Test
    public void arrowUpTest(){
        when(pauseMenuMock.getHighlighted()).thenReturn(1);

        pauseMenuController.arrowUp(gameControllerMock);

        Mockito.verify(pauseMenuMock, times(1)).setHighlighted(4);

        when(pauseMenuMock.getHighlighted()).thenReturn(2);

        pauseMenuController.arrowUp(gameControllerMock);

        Mockito.verify(pauseMenuMock, times(1)).setHighlighted(1);

    }

    @Test
    public void arrowDownTest(){
        when(pauseMenuMock.getHighlighted()).thenReturn(1);

        pauseMenuController.arrowDown(gameControllerMock);

        Mockito.verify(pauseMenuMock, times(1)).setHighlighted(2);

        when(pauseMenuMock.getHighlighted()).thenReturn(4);

        pauseMenuController.arrowDown(gameControllerMock);

        Mockito.verify(pauseMenuMock, times(1)).setHighlighted(1);

    }

    @Test
    public void enterTest(){
        Game gameMock = Mockito.mock(Game.class);

        when(pauseMenuMock.getHighlighted()).thenReturn(1);

        pauseMenuController.enter(gameControllerMock);
        Mockito.verify(gameControllerMock, times(0)).getGame();
        Mockito.verify(gameControllerMock,times(1)).changeStates(any());


        when(gameControllerMock.getGame()).thenReturn(gameMock);
        when(pauseMenuMock.getHighlighted()).thenReturn(2);

        pauseMenuController.enter(gameControllerMock);

        Mockito.verify(gameControllerMock, times(0)).getGame();
        Mockito.verify(gameControllerMock,times(2)).changeStates(any());


        when(pauseMenuMock.getHighlighted()).thenReturn(3);

        pauseMenuController.enter(gameControllerMock);

        Mockito.verify(gameControllerMock, times(0)).getGame();
        Mockito.verify(gameControllerMock,times(3)).changeStates(any());


        when(pauseMenuMock.getHighlighted()).thenReturn(4);

        pauseMenuController.enter(gameControllerMock);

        Mockito.verify(gameControllerMock, times(1)).getGame();
        Mockito.verify(gameMock, times(1)).setFinish(true);
        Mockito.verify(gameControllerMock,times(3)).changeStates(any());


    }

    @Test
    public void escTest(){
        pauseMenuController.esc(gameControllerMock);
        Mockito.verify(gameControllerMock,times(1)).changeStates(any());
    }

    @Test
    public void exitTest(){
        Game gameMock = Mockito.mock(Game.class);

        when(gameControllerMock.getGame()).thenReturn(gameMock);

        pauseMenuController.exit(gameControllerMock);

        Mockito.verify(gameControllerMock, times(1)).getGame();
        Mockito.verify(gameMock, times(1)).setFinish(true);
    }

}
