package game.controller;

import game.model.*;
import game.model.Direction.Direction;
import game.model.State.Arena;
import game.view.ArenaView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

public class ArenaControllerTest {

    Arena arenaMock;
    SnakeController snakeControllerMock;
    EnemiesController enemiesController;
    ArenaView arenaViewMock;
    ArenaController arenaController;
    GameController gameControllerMock;

    @Before
    public void setUp(){
        arenaMock = Mockito.mock(Arena.class);
        snakeControllerMock = Mockito.mock(SnakeController.class);
        enemiesController = Mockito.mock(EnemiesController.class);
        arenaViewMock = Mockito.mock(ArenaView.class);

        arenaController = new ArenaController(arenaMock, snakeControllerMock,arenaViewMock, enemiesController);

        gameControllerMock = Mockito.mock(GameController.class);
    }

    @Test
    public void setArenaTest(){
        SnakeController snakeControllerMock1 = Mockito.mock(SnakeController.class);
        Arena arenaMock1 = Mockito.mock(Arena.class);

        arenaController.setArena(arenaMock1, snakeControllerMock1);

        assertEquals(arenaMock1, arenaController.getArena());
        assertEquals(snakeControllerMock1, arenaController.getSnakeController());
    }

    @Test
    public void getArenaTest(){
        assertEquals(arenaMock, arenaController.getArena());
    }
    @Test
    public void getFramesTest(){
        assertEquals(0, arenaController.getFrames());
    }


    @Test
    public void getSnakeControllerTest(){
        assertEquals(snakeControllerMock, arenaController.getSnakeController());
    }

    @Test
    public void arrowUpTest(){
        when(arenaMock.isMovingObjects()).thenReturn(false);

        arenaController.arrowUp(gameControllerMock);

        Mockito.verify(snakeControllerMock, times(1)).setInitialDirection(new Direction(Direction.Directions.UP));
        Mockito.verify(arenaMock, times(1)).setMovingObjects(true);

        Position positionMock = Mockito.mock(Position.class);
        Game gameMock = Mockito.mock(Game.class);

        when(arenaMock.isMovingObjects()).thenReturn(true);
        when(arenaMock.EnemieInThatPosition(positionMock)).thenReturn(false);
        when(arenaMock.AppleInThatPosition(positionMock)).thenReturn(false);
        when(arenaMock.canMoveTo(positionMock)).thenReturn(true);

        when(snakeControllerMock.getSnakesDirection()).thenReturn(Direction.Directions.DOWN);
        when(snakeControllerMock.snakesUpPosition()).thenReturn(positionMock);

        when(gameControllerMock.getGame()).thenReturn(gameMock);

        arenaController.arrowUp(gameControllerMock);

        Mockito.verify(snakeControllerMock, times(0)).addChangeDirection(new Direction(Direction.Directions.UP));
        Mockito.verify(snakeControllerMock, times(0)).incPositionBody();

        when(arenaMock.canMoveTo(positionMock)).thenReturn(false);

        arenaController.arrowUp(gameControllerMock);

        Mockito.verify(snakeControllerMock, times(0)).addChangeDirection(new Direction(Direction.Directions.UP));
        Mockito.verify(snakeControllerMock, times(0)).incPositionBody();
    }

    @Test
    public void arrowDownTest(){
        when(arenaMock.isMovingObjects()).thenReturn(false);

        arenaController.arrowDown(gameControllerMock);

        Mockito.verify(snakeControllerMock, times(1)).setInitialDirection(new Direction(Direction.Directions.DOWN));
        Mockito.verify(arenaMock, times(1)).setMovingObjects(true);

        Position positionMock = Mockito.mock(Position.class);
        Game gameMock = Mockito.mock(Game.class);

        when(arenaMock.isMovingObjects()).thenReturn(true);
        when(arenaMock.EnemieInThatPosition(positionMock)).thenReturn(false);
        when(arenaMock.AppleInThatPosition(positionMock)).thenReturn(false);
        when(arenaMock.canMoveTo(positionMock)).thenReturn(true);

        when(snakeControllerMock.getSnakesDirection()).thenReturn(Direction.Directions.UP);
        when(snakeControllerMock.snakesDownPosition()).thenReturn(positionMock);

        when(gameControllerMock.getGame()).thenReturn(gameMock);

        when(gameControllerMock.getGame()).thenReturn(gameMock);

        arenaController.arrowDown(gameControllerMock);

        Mockito.verify(snakeControllerMock, times(0)).addChangeDirection(new Direction(Direction.Directions.DOWN));
        Mockito.verify(snakeControllerMock, times(0)).incPositionBody();

        when(arenaMock.canMoveTo(positionMock)).thenReturn(false);

        arenaController.arrowDown(gameControllerMock);

        Mockito.verify(snakeControllerMock, times(0)).addChangeDirection(new Direction(Direction.Directions.DOWN));
        Mockito.verify(snakeControllerMock, times(0)).incPositionBody();
    }

    @Test
    public void arrowLeftTest(){
        when(arenaMock.isMovingObjects()).thenReturn(false);

        arenaController.arrowLeft(gameControllerMock);

        Mockito.verify(snakeControllerMock, times(1)).setInitialDirection(new Direction(Direction.Directions.LEFT));
        Mockito.verify(arenaMock, times(1)).setMovingObjects(true);

        Position positionMock = Mockito.mock(Position.class);
        Game gameMock = Mockito.mock(Game.class);

        when(arenaMock.isMovingObjects()).thenReturn(true);
        when(arenaMock.EnemieInThatPosition(positionMock)).thenReturn(false);
        when(arenaMock.AppleInThatPosition(positionMock)).thenReturn(false);
        when(arenaMock.canMoveTo(positionMock)).thenReturn(true);

        when(snakeControllerMock.getSnakesDirection()).thenReturn(Direction.Directions.RIGHT);
        when(snakeControllerMock.snakesLeftPosition()).thenReturn(positionMock);

        when(gameControllerMock.getGame()).thenReturn(gameMock);

        when(gameControllerMock.getGame()).thenReturn(gameMock);

        arenaController.arrowLeft(gameControllerMock);

        Mockito.verify(snakeControllerMock, times(0)).addChangeDirection(new Direction(Direction.Directions.LEFT));
        Mockito.verify(snakeControllerMock, times(0)).incPositionBody();

        when(arenaMock.canMoveTo(positionMock)).thenReturn(false);

        arenaController.arrowLeft(gameControllerMock);

        Mockito.verify(snakeControllerMock, times(0)).addChangeDirection(new Direction(Direction.Directions.LEFT));
        Mockito.verify(snakeControllerMock, times(0)).incPositionBody();
    }

    @Test
    public void arrowRightTest(){
        when(arenaMock.isMovingObjects()).thenReturn(false);

        arenaController.arrowRight(gameControllerMock);

        Mockito.verify(snakeControllerMock, times(1)).setInitialDirection(new Direction(Direction.Directions.RIGHT));
        Mockito.verify(arenaMock, times(1)).setMovingObjects(true);

        Position positionMock = Mockito.mock(Position.class);
        Game gameMock = Mockito.mock(Game.class);

        when(arenaMock.isMovingObjects()).thenReturn(true);
        when(arenaMock.EnemieInThatPosition(positionMock)).thenReturn(false);
        when(arenaMock.AppleInThatPosition(positionMock)).thenReturn(false);
        when(arenaMock.canMoveTo(positionMock)).thenReturn(true);

        when(snakeControllerMock.getSnakesDirection()).thenReturn(Direction.Directions.LEFT);
        when(snakeControllerMock.snakesRightPosition()).thenReturn(positionMock);

        when(gameControllerMock.getGame()).thenReturn(gameMock);

        when(gameControllerMock.getGame()).thenReturn(gameMock);

        arenaController.arrowRight(gameControllerMock);

        Mockito.verify(snakeControllerMock, times(0)).addChangeDirection(new Direction(Direction.Directions.RIGHT));
        Mockito.verify(snakeControllerMock, times(0)).incPositionBody();

        when(arenaMock.canMoveTo(positionMock)).thenReturn(false);

        arenaController.arrowRight(gameControllerMock);

        Mockito.verify(snakeControllerMock, times(0)).addChangeDirection(new Direction(Direction.Directions.RIGHT));
        Mockito.verify(snakeControllerMock, times(0)).incPositionBody();
    }

    @Test
    public void escTest(){
        arenaController.esc(gameControllerMock);
        Mockito.verify(gameControllerMock,times(1)).changeStates(any());
    }

    @Test
    public void exitTest(){
        Game gameMock = Mockito.mock(Game.class);

        when(gameControllerMock.getGame()).thenReturn(gameMock);

        when(arenaMock.isMovingObjects()).thenReturn(true);

        arenaController.exit(gameControllerMock);

        Mockito.verify(gameControllerMock, times(1)).getGame();
        Mockito.verify(gameMock, times(1)).setFinish(true);
    }

    @Test
    public void noneTest() {
        when(arenaMock.isMovingObjects()).thenReturn(true);
        when(arenaMock.EnemieInThatPosition(any(Position.class))).thenReturn(false);
        when(arenaMock.AppleInThatPosition(any(Position.class))).thenReturn(false);
        when(arenaMock.canMoveTo(any(Position.class))).thenReturn(true);

        GameController gameControllerMock = Mockito.mock(GameController.class);
        Game gameMock = Mockito.mock(Game.class);

        arenaController.none(gameControllerMock);

        when(gameControllerMock.getGame()).thenReturn(gameMock);

        assertEquals(1, arenaController.getFrames());
        Mockito.verify(gameControllerMock, times(0)).gameHasChanged();

        for(int i = 0; i < 3; i++)
            arenaController.none(gameControllerMock);

        assertEquals(4, arenaController.getFrames());
        Mockito.verify(gameControllerMock, times(0)).gameHasChanged();

        arenaController.none(gameControllerMock);

        assertEquals(5, arenaController.getFrames());
        Mockito.verify(gameControllerMock, times(1)).gameHasChanged();
        Mockito.verify(snakeControllerMock, times(1)).snakesNextPosition();
        Mockito.verify(snakeControllerMock, atMost(1)).incPositionBody();

    }
}
