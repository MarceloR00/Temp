package game.controller;


import game.model.*;
import game.model.Direction.Direction;
import game.model.State.ArenaElements.Snake;
import game.view.SnakeView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.*;
import static org.junit.Assert.assertFalse;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

public class SnakeControllerTest {
    Snake snakeMock;
    SnakeView snakeViewMock;
    SnakeController snakeController;
    Position positionBodyPartMock2;

    @Before
    public void setUp(){
        snakeMock = Mockito.mock(Snake.class);

        List<BodyPart> bodyPartList = new ArrayList<>();

        BodyPart bodyPartMock1 = Mockito.mock(BodyPart.class);
        Position positionBodyPartMock1 = Mockito.mock(Position.class);
        when(positionBodyPartMock1.getY()).thenReturn(10);
        when(positionBodyPartMock1.getX()).thenReturn(10);
        when(bodyPartMock1.predictNextPosition()).thenReturn(positionBodyPartMock1);
        bodyPartList.add(bodyPartMock1);

        BodyPart bodyPartMock2 = Mockito.mock(BodyPart.class);
        positionBodyPartMock2 = Mockito.mock(Position.class);
        when(positionBodyPartMock2.getY()).thenReturn(11);
        when(positionBodyPartMock2.getX()).thenReturn(10);
        when(bodyPartMock2.predictNextPosition()).thenReturn(positionBodyPartMock2);
        bodyPartList.add(bodyPartMock2);

        BodyPart bodyPartMock3 = Mockito.mock(BodyPart.class);
        Position positionBodyPartMock3 = Mockito.mock(Position.class);
        when(positionBodyPartMock3.getY()).thenReturn(12);
        when(positionBodyPartMock3.getX()).thenReturn(10);
        when(bodyPartMock3.predictNextPosition()).thenReturn(positionBodyPartMock3);
        bodyPartList.add(bodyPartMock3);

        when(snakeMock.getBody()).thenReturn(bodyPartList);
        snakeViewMock = Mockito.mock(SnakeView.class);

        when(snakeMock.getDirection()).thenReturn(Direction.Directions.UP);
        when(snakeMock.getHeadOfSnake()).thenReturn(bodyPartMock1);
        when(bodyPartMock1.getPosition()).thenReturn(positionBodyPartMock2);

        when(snakeMock.getTailOfSnake()).thenReturn(bodyPartMock3);
        Position positionBodyPartMock4 = Mockito.mock(Position.class);
        when(positionBodyPartMock4.getY()).thenReturn(13);
        when(positionBodyPartMock4.getX()).thenReturn(10);
        when(bodyPartMock3.getPosition()).thenReturn(positionBodyPartMock4);
        when(bodyPartMock3.getDirection()).thenReturn(Direction.Directions.LEFT);

        snakeController = new SnakeController(snakeMock);
    }

    @Test
    public void getSnakeTest(){
        assertEquals(snakeMock, snakeController.getSnake());
    }

    @Test
    public void getSnakesDirectionTest(){
        assertEquals(Direction.Directions.UP, snakeController.getSnakesDirection());
        Mockito.verify(snakeMock, times(1)).getDirection();
    }

    @Test
    public void setInitialDirectionTest(){
        Direction directionMock = Mockito.mock(Direction.class);

        snakeController.setInitialDirection(directionMock);
        Mockito.verify(snakeMock, times(1)).setInitialDirection(directionMock);
    }

    @Test
    public void snakesUpPositionTest(){
        snakeController.snakesUpPosition();
        Mockito.verify(snakeMock, times(1)).upPosition();
    }

    @Test
    public void snakesDownPositionTest(){
        snakeController.snakesDownPosition();
        Mockito.verify(snakeMock, times(1)).downPosition();
    }

    @Test
    public void snakesRightPositionTest(){
        snakeController.snakesRightPosition();
        Mockito.verify(snakeMock, times(1)).rightPosition();
    }
    @Test
    public void snakesLeftPositionTest(){
        snakeController.snakesLeftPosition();
        Mockito.verify(snakeMock, times(1)).leftPosition();
    }

    @Test
    public void snakesNextPositionTest(){
        snakeController.snakesNextPosition();
        Mockito.verify(snakeMock, times(1)).getNextPosition();
    }

    @Test
    public void addChangeDirectionTest(){
        Direction directionMock = Mockito.mock(Direction.class);

        snakeController.addChangeDirection(directionMock);

        Mockito.verify(snakeMock, times(1)).getBody();

        Mockito.verify(snakeMock.getBody().get(0), times(1)).setDirection(directionMock);
        Mockito.verify(snakeMock.getBody().get(1), times(1)).addChangeDirections(any(),any());
        Mockito.verify(snakeMock.getBody().get(2), times(1)).addChangeDirections(any(),any());
    }

    @Test
    public void incPositionBodyTest(){
        snakeController.incPositionBody();

        Mockito.verify(snakeMock.getBody().get(0), times(1)).goNextPosition();
        Mockito.verify(snakeMock.getBody().get(1), times(1)).goNextPosition();
        Mockito.verify(snakeMock.getBody().get(2), times(1)).goNextPosition();
    }

    @Test
    public void addNewBodyPartTest(){
        Position positionMock = Mockito.mock(Position.class);
        Direction directionMock = Mockito.mock(Direction.class);

        when(directionMock.getDirection()).thenReturn(Direction.Directions.RIGHT);

        assertEquals( 3, snakeMock.getBody().size());
        snakeController.addNewBodyPart(positionMock,directionMock);
        assertEquals( 4, snakeMock.getBody().size());

        Mockito.verify(directionMock,times(1)).getDirection();
        Mockito.verify(positionMock,times(1)).leftPosition();
        Mockito.verify(positionMock,times(0)).rightPosition();
        Mockito.verify(positionMock,times(0)).upPosition();
        Mockito.verify(positionMock,times(0)).downPosition();

        when(directionMock.getDirection()).thenReturn(Direction.Directions.LEFT);
        snakeController.addNewBodyPart(positionMock,directionMock);
        assertEquals( 5, snakeMock.getBody().size());


        Mockito.verify(directionMock,times(2)).getDirection();
        Mockito.verify(positionMock,times(1)).leftPosition();
        Mockito.verify(positionMock,times(1)).rightPosition();
        Mockito.verify(positionMock,times(0)).upPosition();
        Mockito.verify(positionMock,times(0)).downPosition();

        when(directionMock.getDirection()).thenReturn(Direction.Directions.UP);
        snakeController.addNewBodyPart(positionMock,directionMock);
        assertEquals( 6, snakeMock.getBody().size());


        Mockito.verify(directionMock,times(3)).getDirection();
        Mockito.verify(positionMock,times(1)).leftPosition();
        Mockito.verify(positionMock,times(1)).rightPosition();
        Mockito.verify(positionMock,times(0)).upPosition();
        Mockito.verify(positionMock,times(1)).downPosition();

        when(directionMock.getDirection()).thenReturn(Direction.Directions.DOWN);
        snakeController.addNewBodyPart(positionMock,directionMock);
        assertEquals( 7, snakeMock.getBody().size());


        Mockito.verify(directionMock,times(4)).getDirection();
        Mockito.verify(positionMock,times(1)).leftPosition();
        Mockito.verify(positionMock,times(1)).rightPosition();
        Mockito.verify(positionMock,times(1)).upPosition();
        Mockito.verify(positionMock,times(1)).downPosition();
    }

    @Test
    public void copyLastPositionTest(){
        Position testPosition = snakeController.copyLastPosition();
        assertEquals(10,testPosition.getX());
        assertEquals(13,testPosition.getY());

        Mockito.verify(snakeMock,times(2)).getTailOfSnake();
        Mockito.verify(snakeMock.getTailOfSnake(),times(2)).getPosition();
        Mockito.verify(snakeMock.getTailOfSnake().getPosition(),times(1)).getX();
        Mockito.verify(snakeMock.getTailOfSnake().getPosition(),times(1)).getY();
    }

    @Test
    public void copyLastDirectionTest(){
        Direction testDirection= snakeController.copyLastDirection();

        assertEquals(Direction.Directions.LEFT,testDirection.getDirection());

        Mockito.verify(snakeMock,times(1)).getTailOfSnake();
        Mockito.verify(snakeMock.getTailOfSnake(),times(1)).getDirection();
    }

    @Test
    public void BodyPartInThatPositionTest(){
        Position positionMock = Mockito.mock(Position.class);

        when(positionMock.getX()).thenReturn(5);
        when(positionMock.getY()).thenReturn(10);

        assertFalse(snakeController.BodyPartInThatPosition(positionMock));

        assertTrue(snakeController.BodyPartInThatPosition(positionBodyPartMock2));
    }
}
