package game.controller;

import game.model.Game;
import game.model.State.MainMenu;
import game.view.MainMenuView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

public class MainMenuControllerTest {
    MainMenu mainMenuMock;
    MainMenuView mainMenuViewMock;
    MainMenuController mainMenuController;

    @Before
    public void setUp(){
        this.mainMenuMock = Mockito.mock(MainMenu.class);
        this.mainMenuViewMock = Mockito.mock(MainMenuView.class);
        this.mainMenuController = new MainMenuController(mainMenuMock,mainMenuViewMock);
    }

    @Test
    public void getMainMenuTest(){
        assertEquals(mainMenuMock, mainMenuController.getMainMenu());
    }

    @Test
    public void arrowUpTest(){
        GameController gameControllerMock = Mockito.mock(GameController.class);

        when(mainMenuMock.getHighlighted()).thenReturn(1);

        mainMenuController.arrowUp(gameControllerMock);

        Mockito.verify(mainMenuMock, times(1)).setHighlighted(2);

        when(mainMenuMock.getHighlighted()).thenReturn(2);

        mainMenuController.arrowUp(gameControllerMock);

        Mockito.verify(mainMenuMock, times(1)).setHighlighted(1);

    }

    @Test
    public void arrowDownTest(){
        GameController gameControllerMock = Mockito.mock(GameController.class);

        when(mainMenuMock.getHighlighted()).thenReturn(1);

        mainMenuController.arrowDown(gameControllerMock);

        Mockito.verify(mainMenuMock, times(1)).setHighlighted(2);

        when(mainMenuMock.getHighlighted()).thenReturn(2);

        mainMenuController.arrowDown(gameControllerMock);

        Mockito.verify(mainMenuMock, times(1)).setHighlighted(1);

    }

    @Test
    public void enterTest(){
        GameController gameControllerMock = Mockito.mock(GameController.class);;
        Game gameMock = Mockito.mock(Game.class);

        when(mainMenuMock.getHighlighted()).thenReturn(1);
        when(gameControllerMock.getGame()).thenReturn(gameMock);
        when(gameMock.getWidth()).thenReturn(100);
        when(gameMock.getHeight()).thenReturn(100);
        when(gameMock.getLevel()).thenReturn(1);

        mainMenuController.enter(gameControllerMock);

        Mockito.verify(gameMock, times(1)).setLevel(1);
        Mockito.verify(gameControllerMock, times(1)).getGame();
        Mockito.verify(gameControllerMock,times(1)).changeStates(any());


        when(mainMenuMock.getHighlighted()).thenReturn(2);
        when(gameControllerMock.getGame()).thenReturn(gameMock);

        mainMenuController.enter(gameControllerMock);

        Mockito.verify(gameControllerMock, times(2)).getGame();
        Mockito.verify(gameMock, times(1)).setFinish(true);
        Mockito.verify(gameControllerMock,times(1)).changeStates(any());
    }

    @Test
    public void exitTest(){
        GameController gameControllerMock = Mockito.mock(GameController.class);
        Game gameMock = Mockito.mock(Game.class);

        when(gameControllerMock.getGame()).thenReturn(gameMock);

        mainMenuController.exit(gameControllerMock);

        Mockito.verify(gameControllerMock, times(1)).getGame();
        Mockito.verify(gameMock, times(1)).setFinish(true);

    }

}
