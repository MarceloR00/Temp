package game.controller;

import game.factory.stateFactory.LoseMenuFactory;
import game.model.State.Arena;
import game.model.Game;
import game.model.State.LoseMenu;
import game.view.GameView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class GameControllerTest {

    Game gameMock;
    GameView gameViewMock;
    ArenaController arenaControllerMock;
    MainMenuController mainControllerMock;
    GameController gameController;

    @Before
    public void setUp() {
        this.gameMock = Mockito.mock(Game.class);
        this.gameViewMock = Mockito.mock(GameView.class);
        this.arenaControllerMock = Mockito.mock(ArenaController.class);
        this.mainControllerMock = Mockito.mock(MainMenuController.class);
        gameController = new GameController(gameMock, mainControllerMock,gameViewMock);
    }

    @Test
    public void setControllerStateTest(){
        ArenaController arenaControllerMock2 = Mockito.mock(ArenaController.class);

        gameController.setControllerState(arenaControllerMock2);

        assertEquals(arenaControllerMock2, gameController.getControllerState());
    }

    @Test
    public void getControllerStateTest(){
        assertEquals(mainControllerMock, gameController.getControllerState());
    }

    @Test
    public void changeArenasTest(){
        ArenaController arenaControllerMock2 = Mockito.mock(ArenaController.class);
        Arena arenaMock = Mockito.mock(Arena.class);

        when(arenaControllerMock2.getArena()).thenReturn(arenaMock);

        gameController.changeArenas(arenaControllerMock2);

        assertNotEquals(arenaControllerMock, gameController.getArenaController());
        assertEquals(arenaControllerMock2, gameController.getArenaController());
        Mockito.verify(gameMock, times(1)).setArena(arenaMock);
    }

    @Test
    public void changeStatesTest(){
        LoseMenuFactory loseMenuFactoryMock = Mockito.mock(LoseMenuFactory.class);
        LoseMenu loseMenuMock = Mockito.mock(LoseMenu.class);
        LoseMenuController loseMenuControllerMock = Mockito.mock(LoseMenuController.class);

        when(loseMenuFactoryMock.createState(gameController)).thenReturn(loseMenuMock);
        when(loseMenuFactoryMock.createStateController(gameController, loseMenuMock)).thenReturn(loseMenuControllerMock);

        gameController.changeStates(loseMenuFactoryMock);

        Mockito.verify(loseMenuFactoryMock, times(1)).createState(gameController);
        Mockito.verify(gameMock, times(1)).setState(loseMenuMock);
        Mockito.verify(loseMenuFactoryMock, times(1)).createStateController(gameController, loseMenuMock);
    }

    @Test
    public void getArenaControllerTest(){
        Arena arenaMock = Mockito.mock(Arena.class);
        when(arenaControllerMock.getArena()).thenReturn(arenaMock);
        gameController.changeArenas(arenaControllerMock);
        assertEquals(arenaControllerMock, gameController.getArenaController());
        Mockito.verify(gameMock, times(1)).setArena(arenaMock);
    }

    @Test
    public void getGameTest(){
        assertEquals(gameMock, gameController.getGame());
    }

    @Test
    public void arenaElementsArenaMovingTest(){
        Arena arenaMock = Mockito.mock(Arena.class);

        when(arenaMock.isMovingObjects()).thenReturn(true);
        when(arenaControllerMock.getArena()).thenReturn(arenaMock);
        gameController.changeArenas(arenaControllerMock);

        gameController.arenaElementsArenaMoving();

        Mockito.verify(arenaMock, times(1)).isMovingObjects();
        assertTrue(gameController.arenaElementsArenaMoving());
    }

    @Test
    public void arrowUpTest(){
        gameController.arrowUp();

        Mockito.verify(mainControllerMock,times(1)).arrowUp(gameController);
    }

    @Test
    public void arrowDownTest(){
        gameController.arrowDown();

        Mockito.verify(mainControllerMock,times(1)).arrowDown(gameController);
    }

    @Test
    public void arrowLeftTest(){
        gameController.arrowLeft();

        Mockito.verify(mainControllerMock,times(1)).arrowLeft(gameController);
    }

    @Test
    public void arrowRightTest(){
        gameController.arrowRight();

        Mockito.verify(mainControllerMock,times(1)).arrowRight(gameController);

    }

    @Test
    public void enterTest(){
        gameController.enter();

        Mockito.verify(mainControllerMock,times(1)).enter(gameController);
    }

    @Test
    public void escTest(){
        gameController.esc();

        Mockito.verify(mainControllerMock,times(1)).esc(gameController);
    }

    @Test
    public void exitTest(){
        gameController.exit();

        Mockito.verify(mainControllerMock,times(1)).exit(gameController);
    }

    @Test
    public void noneTest(){
        gameController.none();

        Mockito.verify(mainControllerMock, times(1)).none(gameController);

    }

}
