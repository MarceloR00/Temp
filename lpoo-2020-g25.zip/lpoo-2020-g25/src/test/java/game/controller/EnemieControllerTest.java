package game.controller;

import game.model.State.Arena;
import game.model.State.ArenaElements.Enemie.Enemie;
import game.model.Position;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

public class EnemieControllerTest {
    Arena arenaMock;
    Enemie enemieMock;
    Position positionMock;
    List<Enemie> enemiesMock = new ArrayList<>();

    @Before
    public void setUp(){
        arenaMock = Mockito.mock(Arena.class);
        positionMock = Mockito.mock(Position.class);
        enemieMock = Mockito.mock(Enemie.class);
        enemiesMock.add(enemieMock);
        enemiesMock.add(enemieMock);
        enemiesMock.add(enemieMock);
        enemiesMock.add(enemieMock);
    }

    @Test
    public void moveTest(){
        EnemiesController enemiesController = new EnemiesController(arenaMock);

        when(arenaMock.getEnemies()).thenReturn(enemiesMock);
        when(enemieMock.getNextPosition()).thenReturn(positionMock);
        when(arenaMock.arenaContainObjectInPosition(positionMock)).thenReturn(false);

        enemiesController.move();

        Mockito.verify(arenaMock, times(1)).getEnemies();
        Mockito.verify(enemieMock, times(4)).getNextPosition();
        Mockito.verify(arenaMock, times(4)).arenaContainObjectInPosition(positionMock);
        Mockito.verify(enemieMock, times(4)).setPosition(positionMock);

        when(arenaMock.arenaContainObjectInPosition(positionMock)).thenReturn(true);

        enemiesController.move();

        Mockito.verify(arenaMock, times(2)).getEnemies();
        Mockito.verify(enemieMock, times(8)).getNextPosition();
        Mockito.verify(arenaMock, times(8)).arenaContainObjectInPosition(positionMock);
        Mockito.verify(enemieMock, times(4)).setPosition(positionMock);

    }
}
