package game.controller;

import game.factory.stateFactory.ArenaFactory;
import game.model.Game;
import game.model.State.LevelTransaction;
import game.view.LevelTransactionView;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

public class LevelTransactionControllerTest {

    LevelTransaction levelTransactionMock;
    LevelTransactionView levelTransactionViewMock;
    LevelTransactionController levelTransactionController;

    @Before
    public void setUp() {
        this.levelTransactionMock = Mockito.mock(LevelTransaction.class);
        this.levelTransactionViewMock = Mockito.mock(LevelTransactionView.class);
        levelTransactionController = new LevelTransactionController(levelTransactionMock, levelTransactionViewMock);
    }

    @Test
    public void getFramesTest() {
        assertEquals(0, levelTransactionController.getFrames());
    }

    @Test
    public void getLevelTransactionTest() {
        assertEquals(levelTransactionMock, levelTransactionController.getLevelTransaction());
    }

    @Test
    public void exitTest() {
        GameController gameControllerMock = Mockito.mock(GameController.class);
        Game gameMock = Mockito.mock(Game.class);

        when(gameControllerMock.getGame()).thenReturn(gameMock);

        levelTransactionController.exit(gameControllerMock);

        Mockito.verify(gameControllerMock, times(1)).getGame();
        Mockito.verify(gameMock, times(1)).setFinish(true);

    }

    @Test
    public void noneTest() {
        GameController gameControllerMock = Mockito.mock(GameController.class);
        Game gameMock = Mockito.mock(Game.class);
        ArenaController stateController = Mockito.mock(ArenaController.class);

        when(gameControllerMock.getGame()).thenReturn(gameMock);
        when(gameControllerMock.getControllerState()).thenReturn(stateController);

        levelTransactionController.none(gameControllerMock);

        Mockito.verify(gameControllerMock, times(0)).changeStates(any(ArenaFactory.class));
        Mockito.verify(gameControllerMock, times(0)).changeArenas(stateController);
        Mockito.verify(gameControllerMock, times(0)).gameHasChanged();
        Mockito.verify(gameControllerMock, times(0)).getControllerState();

        for(int i = 0; i < 118; i++){
            levelTransactionController.none(gameControllerMock);

            Mockito.verify(gameControllerMock, times(0)).changeStates(any(ArenaFactory.class));
            Mockito.verify(gameControllerMock, times(0)).changeArenas(stateController);
            Mockito.verify(gameControllerMock, times(0)).gameHasChanged();
            Mockito.verify(gameControllerMock, times(0)).getControllerState();
        }

        levelTransactionController.none(gameControllerMock);

        Mockito.verify(gameControllerMock, times(1)).changeStates(any(ArenaFactory.class));
        Mockito.verify(gameControllerMock, times(1)).changeArenas(stateController);
        Mockito.verify(gameControllerMock, times(1)).gameHasChanged();
        Mockito.verify(gameControllerMock, times(1)).getControllerState();

    }
}
