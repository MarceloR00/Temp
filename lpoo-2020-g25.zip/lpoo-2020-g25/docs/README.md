LPOO_25 - "Snake goes to the Jungle"
====================================

Neste jogo o utilizador controla uma snake cujo principal objetivo é apanhar o número de maçãs presentes no atual nivel, sem que seja apanhada por algum dos inimigos e sem tocar no seu próprio corpo, um pouco baseado no jogo original.
Este projeto está a ser desenvolvido pelo Diogo Santos (up201806878@fe.up.pt) e pelo Marcelo Reis (up201809566@fe.up.pt) para LPOO 2019/20.

Funcionalidades Implementadas
-----------------------------

Atualmente no nosso jogo temos as seguintes funcionalidades:

**Representação dos Inimigos, Snake, Maçãs e Árvores:** A snake atualmente encontra-se numa floresta rodeada por inimigos e árvores, e ainda por maçãs que tem de apanhar para passar o nível.

**Movimento da Snake:** A snake move-se seguindo uma dada direção para a fazer mudar de direção podemos carregar num das setas.

**Snake Cresce:** A medida que a snake come as maçãs vai crescendo.

**Legendas:** No canto inferior do ecrã aparece a indicação do número de maçãs restantes, o nível, o número de árvores e inimigos.

**Menu de Derrota:** Caso algum inimigo e a snake se toquem aparece o menu de derrota, onde é possível decidir se se quer jogar novamente, _Play Again_, ou sair do jogo, _Exit_.

**Menu Principal:** Quando o jogo é iniciado aparece no ecrã o Menu Principal onde é possivel selecionar a opção de jogar, _Play_, e sair do jogo, _Exit_.

**Menu de Pausa:** Quando nós encontramos em modo de jogo, ou seja, na arena se clicarmos na tecla _ESC_ o Menu de Pausa aparece, uma vez lá podemos voltar para o jogo selecionando a opção _Resume_, ou clicando na tecla _Esc_, pode-se slecionar _Restart_ que cria uma nova arena para o nivel atual, podemos voltar para o Menu Principal com _Main Menu_ ou sair do jogo _Exit_.

Funcionalidades Futuras
-----------------------

Numa fase posterior pretende-mos fazer os seguintes pontos:

**Tipo de Inimigos:** colocar mais que um tipo de inimigos, cada um com o seu tipo de movimento;

**Registo de Pontuações:** guardar as 5 melhores pontuações obtidas no jogo.

Design
------

* **Contexto do Problema:** Um dos grandes problemas que nos deparamos ao desenvolver este jogo foi a forma como os dados se deveriam relacionar. Para podermos desenvolver um jogo é necessário guardarmos os dados, é necessário recolher os inputs, é necessário desenvolver o "desenho" do jogo, no fundo preparar a sua interface com o utilizador e por fim a decisão, ou seja, o que fazer quando o utilizador prime uma dada tecla, ou não prime. Ao introduzir-mos isto tudo numa classe iriamos ocorrer numa violação do **Single Responsability Principle** pois a classe iria ter mais que uma função ela teria que se saber desenhar, saber o que fazer no caso de algum evento acontecer e ainda guardar os dados.

* **Padrão:** Decidimos usar [MVC](https://www.geeksforgeeks.org/mvc-design-pattern/). Ao usarmos este padrão conseguimos separar as várias responsabilidades por várias classes, sendo que uma é responsável por guardar os dados, outra é responsável pela apresentação da informação e a outra pelo controlo de informação.

* **Implementação:** O diagrama seguinte mostra como o padrão funciona e o seu papel nas classes.

   ![Image](MVC.png)

Estas classes podem ser encontradas aqui:

   * [GameController](../code/src/main/java/game/controller/GameController.java)

   * [GameView](../code/src/main/java/game/view/GameView.java)

   * [Game](../code/src/main/java/game/model/Game.java)

   É importante de notar que este padrão aplica-se a muitas outras classes este é apenas um exemplo. A classe **Game** contém apenas a informação relativa ao jogo, tal como: as dimensões da janela(_width_ e _height_), o nivel(_level_) em que o jogo se encontra e se é suposto acabar o jogo(_finish_). A classe **GameController** contém o **Game**, o **GameView** e é responsável por gerir os eventos que o utilizador causa, ou não de pendendo se premiu alguma tecla ou não. A fim de tal acontecer temos de chamar a função _run()_ que inicia o jogo e lá questiona "eternamente", num ciclo infinito, o **GameView** em relação a eventuais inputs, em função disso o **GameView** diz ao Controller para executar uma determinada ação e por último caso essa ação provoque alguma alteração no jogo a função _draw(StateController stateController)_ é chamada e desenha no ecrã o atual estado do jogo. Por fim o jogo acaba quando o utilizador seleciona a opção exit, o que vai fazer com que o _finish_ do game seja colocado a _true_ logo o ciclo é interrompido e o **GameController** chama a função _endGame()_ do **GameView** que vai fechar o ecrã.

* **Consequências:** O uso deste padrão permite-nos ter alguns beneficios tais como:

   * Faz com que não violemos o **Single Responsability Principle**, organizando o código referente aos estados em diferentes classes;

   * Permite-nos simplificar imenso código, tornando-o muito mais fácil de perceber tanto para nós como para eventuais colaboradores;
  
   * Permite também que um modelo tenha múltiplas vistas;

   * Torna-se também muito mais fácil alterar o código, sendo muito mais fácil atualizá-lo caso queiramos, seguindo assim o **Open-Closed Principle** que defende que um módulo deve poder ser extendido sem sequer ser preciso modificá-lo.

---

* **Contexto do Problema:** Este jogo, tal como muitos outros, pode encontrar-se em diferentes estados: Menu Principal, Menu de Pausa e Modo de Jogo(Arena). Como tal pode ser representado por uma máquina de estados em que do Menu Principal podemos ir para o Modo de Jogo, do Modo de Jogo podemos ir para o Menu de Pausa e do Menu de Pausa podemos retomar ao Modo de Jogo(continuando de onde o tinhamos deixado ou recomeçando), mas também podemos voltar ao Menu Principal, etc... Isto constitui uma violação do **Single Responsability Principle** que nos diz que um módulo deve ter apenas uma responsabilidade.

   ![Image](StateMachine.png)

* **Padrão:** Decidimos usar [State Pattern](https://refactoring.guru/design-patterns/state). Este padrão permite-nos alterar o seu comportamento quando o seu estado interno se altera. Desta forma conseguimos livrar-nos de uma data de "ifs statements" que iriam ser necessários para representar esta "máquina de estados" que é o nosso jogo.

* **Implementação:** O diagrama seguinte mostra como o padrão funciona e o seu papel nas classes.

   ![Image](UMLClassState.png)

Estas classes podem ser encontradas aqui:

   * [GameController](../code/src/main/java/game/controller/GameController.java)

   * [StateController](../code/src/main/java/game/controller/StateController.java)

   * [MainMenuController](../code/src/main/java/game/controller/MainMenuController.java)

   * [PauseMenuController](../code/src/main/java/game/controller/PauseMenuController.java)

   * [LoseMenuController](../code/src/main/java/game/controller/LoseMenuController.java)

   * [LevelTransactionController](../code/src/main/java/game/controller/LevelTransactionController.java)

   * [ArenaController](../code/src/main/java/game/controller/ArenaController.java)

   O **GameController** contém uma instância do **StateController** que será alterado ao longo do jogo, através da função _changeStateController(StateFactory stateFactory)_. **StateController** é uma classe abstrata que contém as várias funções que correspondem aos eventos que o utilizador causou e que influenciam a mudança de estado. As restantes classes são os diferentes estados que o jogo pode assumir e como tal têm comportamentos próprios, alguns deles que dependem do usuário e outros que apenas do tempo que vai passando.

* **Consequências:** O uso deste padrão permite-nos ter alguns beneficios tais como:

   * Faz com que não violemos o **Single Responsability Principle**, organizando o código referente aos estados em diferentes classes;

   * Permite-nos simplificar imenso código livrando-nos assim de um monte de "ifs" e "elses" através do polimorfismo.

---

* **Contexto do Problema:** Ao executar-mos a função _changeStateController()_ deparamo-nos com um problema que foi na passagem do parámetro pois para o passarmos seriamos forçados a criar uma instância dessa classe dentro de uma função o que nos iria complicar muito o processo dos testes pois não iríamos conseguir fazer um mock, daí termos pensado  em instanciar a classe numa função que só teria como propósito isso mesmo, instanciá-la, ou seja, pensamos em fazer um factory. Outro problema, é que essa classe poderia ser uma classe qualquer que extende-se o **State Controller**, ou sej,a teriamos de ter vários métodos que permitissem cada um instanciar um diferente tipo de State, logo fizemos várias classes cada uma com uma função que permitisse instanciar um diferente tipo de classe.

* **Padrão:** Decidimos usar [Abstract Factory Pattern](https://refactoring.guru/design-patterns/abstract-factory). Este padrão permite-nos instanciar a partir da abstract factory, objetos concretos tornando assim possível a resolução do nosso problema de instanciação de várias classes dentro de uma função resolúvel.

* **Implementação:** O diagrama seguinte mostra como o padrão funciona e o seu papel nas classes.

   ![Image](AbstractFactory.png)

Estas classes podem ser encontradas aqui:

   * [StateFactory](../code/src/main/java/game/factory/StateFactory.java)

   * [MainMenuFactory](../code/src/main/java/game/factory/MainMenuFactory.java)

   * [PauseMenuFactory](../code/src/main/java/game/factory/PauseMenuFactory.java)

   * [LoseMenuFactory](../code/src/main/java/game/factory/LoseMenuFactory.java)

   * [LevelTransactionFactory](../code/src/main/java/game/factory/LevelTransactionFactory.java)

   * [ArenaFactory](../code/src/main/java/game/factory/ArenaFactory.java)

   * [BackArenaFactory](../code/src/main/java/game/factory/BackArenaFactory.java)

   * [GameController](../code/src/main/java/game/controller/GameController.java)

   Na função _changeStateController(StateFactory stateFactory)_ passámos portanto uma abstrac factory que contém o método _createStateController(GameController gameController)_ que  instância um tipo de **StateController** consoante o objeto concreto que foi passado com parámetro, fazendo assim com que o nosso código seja muito mais fácil de perceber e muito mais simples de implementar, basta-nos apenas decidir para que estado de jogo queremos mudar e passámos a "fábrica" desse método como parámetro, que depois será usado dentro da função _changeStateController(StateFactory stateFactory)_ para criar o estdo que pretendemos.

* **Consequências:** O uso deste padrão permite-nos ter alguns beneficios tais como:

   * Evita a instanciação de classes dentro de funções permitindo assim alguma facilidade na produção dos testes;

   * Conseguimos livrar um dado módulo de fazer tarefas que não são da sua responsabilidade, permitindo assim seguir o **Single Responsability Principle**;
   
   * Podemos também portanto criar novos estados do jogo que depois não irá influenciar em nada esta função de alterar o estado do jogo, faz com que apenas crie-mos outra factory concreta, e problema resolvido, conseguindo assim também repeitar o **Open-Closed Principle**.

"Code Smells" Conhecidos e Sugestões de "Refactoring"
------------------------------------------------------

* **Data Class**

   A classe [Snake](../code/src/main/java/game/model/Snake.java) é uma **Data Class**, e como tal contém atributos e métodos simples para os manipular bem como alguns comportamentos. Existe um método presente na classe [SnakeController](../code/src/main/java/game/controller/SnakeController.java) denominado de [BodyPartInThatPosition()](../code/src/main/java/game/controller/SnakeController.java#L98-L106) que realiza uma verificação apenas utilizando dados da Snake, o que pode trazer problemas de estrutura de código pois este método pode muito bem estar na **Data Class** [Snake](../code/src/main/java/game/model/Snake.java).
   Uma forma de melhorar o código seria essa de mover o método [BodyPartInThatPosition()](../code/src/main/java/game/controller/SnakeController.java#L98-L106) para a [Snake](../code/src/main/java/game/model/Snake.java).  
   
* **Shotgun Surgery**

   As subclasses de [StateController](../code/src/main/java/game/controller/StateController.java), como p.e [ArenaController](../code/src/main/java/game/controller/ArenaController.java), têm um atributo que trata da forma como são apresentados os seus dados no ecrã. Isto pode trazer problemas futuros, pois se caso pretendermos inserir mais que uma forma de apresentar esses dados vamos necessitar de fazer algumas pequenas alterações em várias classes, principalmente as subclasses de [StateController](../code/src/main/java/game/controller/StateController.java).
   Uma sugestão seria criar uma superclasse, como p.e "View" ,que podia ser *extended* por todas as classes view.

* **Lazy Class**

   As subclasses de [Menu](../code/src/main/java/game/model/Menu.java) como o [MainMenu](../code/src/main/java/game/model/MainMenu.java), [PauseMenu](../src/main/java/game/model/PauseMenu.java) e [LoseMenu](../src/main/java/game/model/LoseMenu.java) são ridiculamente pequenas, isto é, têm apenas o construtor, e este apenas chama o construtor da superclasse [Menu](../code/src/main/java/game/model/Menu.java). Isto não traz grandes vantagens pois todo o "trabalho" é realizado pela superclasse.
   A solução que propomos é o [*Collapse Hierarchy*](https://refactoring.guru/collapse-hierarchy) ficando apenas com a superclasse [Menu](../code/src/main/java/game/model/Menu.java).
  
* **Duplicated Code**
   
   Quando lidamos com o tratamento de acontecimentos na classe [ArenaController](../code/src/main/java/game/controller/ArenaController.java) como o [arrowUp()](../src/main/java/game/controller/ArenaController.java#L41-L56), [arrowDown()](../src/main/java/game/controller/ArenaController.java#L59-L74) e etc repetimos código, isto é, existe mais que um método com código praticamente idêntico. Isto traz problemas porque para além de termos muito mais linhas de código que o necessário torna-se mais dificil de ler e entender.
   Uma solução é criar um método que contenha esse código para quando for necessário. 
   
* **Switch Statements**

   A classe [GameView](../code/src/main/java/game/view/GameView.java) é responsável pela criação da interface gráfica. Esta lida também com a receção de Inputs por parte do utilizador através do método [getNextCommand()](../code/src/main/java/game/view/GameView.java#L27-L43), mas para saber qual foi esse Input utilizamos uma "chuva" de *ifs* o que faz com que seja muito confuso para quem está a ler o código.
   Para resolvermos este problema propomos substituir esses *ifs* por um *switch case* mais simples.
   
Testes
------

   *Screenshots* da nossa cobertura de testes:
   
   ![Image](TestCoverage1.png)
   
   ![Image](TestCoverage2.png)

Auto Avaliação
--------------

* Diogo Santos - 50%
* Marcelo Reis - 50%
