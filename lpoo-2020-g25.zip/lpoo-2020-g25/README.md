LPOO_25 - "Snake goes to the Jungle"
====================================

Neste jogo o utilizador controla uma snake cujo principal objetivo é apanhar o número de maçãs presentes no atual nivel, sem que seja apanhada por algum dos inimigos e sem tocar no seu próprio corpo, um pouco baseado no jogo original.
Este projeto está a ser desenvolvido pelo Diogo Santos (up201806878@fe.up.pt) e pelo Marcelo Reis (up201809566@fe.up.pt) para LPOO 2019/20.
